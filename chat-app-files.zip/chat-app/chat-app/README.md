# Multi-Client Chat Application (Java Sockets + JavaFX)

A group chat built on **TCP sockets**: one central server distributes messages between any number of
JavaFX clients. Mini Project 1 – Java network programming.

| Project | Role | Main class |
|---|---|---|
| `TCPServer/` | Central server with live user list and activity log | `TCPServer` |
| `TCPClient/` | Chat client (login screen, chat screen, read-only mode) | `TCPClient` |

## Requirements covered

| Requirement | Where |
|---|---|
| Server–client architecture, server redistributes messages | `ChatServer.broadcastChat` |
| Username before entering the chat | `LoginView` |
| **READ-ONLY MODE** when no username is given | blank username → `OK\|READONLY`; input disabled in `ChatView`; the server also refuses `MSG` from viewers |
| Send with **SEND** button or **Enter** (Shift+Enter = new line) | `ChatView` |
| `allUsers` command → list of active clients to that user only | `ChatClient.sendUserInput` → `CMD\|allUsers` → `USERS\|…` |
| Disconnect with `end`, `bye` or **LEAVE**; server is notified | `ChatClient.disconnect` sends `BYE` |
| "Online" label + coloured circle (turns red/“Offline” if the link drops) | `ChatView.setConnected` |
| Multiple concurrent clients, **virtual threads** | `Executors.newVirtualThreadPerTaskExecutor()` in `ChatServer` |
| Message formatted with username and time | `MSG\|HH:mm:ss\|user\|text` |
| Server `ListView` of users with **random background colours** | `ServerView` |
| Log: "Server Started", "Waiting for Client", "Welcome [User]" … | `ServerListener.onLog` |
| IP/port from a **properties file**, no recompilation | `server.properties`, `client.properties` |
| **Model / View decoupling** | `model` packages contain no JavaFX; see below |
| JavaFX with `GridPane` + CSS | `view` packages, `resources/css/*.css` |
| Command lines `java TCPClient <ip> <port>` / `java TCPServer` | `TCPClient.java`, `TCPServer.java` (default package) |

## Architecture

```
TCPServer/src/main/java
├── TCPServer.java                      entry point (java TCPServer)
└── com/chatapp/server
    ├── ServerApp.java                  JavaFX Application, wires M-V-C
    ├── controller/ServerController     model events -> UI (Platform.runLater), UI actions -> model
    ├── view/ServerView                 GridPane + CSS, no socket code
    └── model/                          NO JavaFX imports
        ├── ChatServer                  accept loop, broadcast, name registry
        ├── ClientHandler               one virtual thread per client
        ├── ServerListener              observer interface (log / join / leave)
        ├── ServerConfig                properties loading
        └── Protocol                    wire format helpers

TCPClient/src/main/java  (same layering)
├── TCPClient.java                      entry point (java TCPClient <ip> <port>)
└── com/chatapp/client
    ├── ClientApp, controller/ClientController
    ├── view/LoginView, view/ChatView
    └── model/ChatClient, ClientListener, ChatMessage, ClientConfig, Protocol, ServerRejectedException
```

The **model** talks to the outside only through listener interfaces (`ServerListener`, `ClientListener`).
The JavaFX controller implements them; a unit test or a console front-end could implement them just as well.
That is how the tests run the complete server and client **without starting JavaFX**.

### Wire protocol (one UTF-8 line per frame)

```
client -> server                    server -> client
JOIN|<username>   (blank=read-only) OK|USER | OK|READONLY | ERR|<reason>
MSG|<text>                          MSG|<HH:mm:ss>|<sender>|<text>
CMD|allUsers                        USERS|alice,bob
BYE                                 SYS|<notice>
```
Newlines inside a message are escaped as `\n`, so multi-line messages (Shift+Enter) stay on one line.
Usernames: 1–20 chars (letters, digits, space, `_ - .`), unique case-insensitively.

### Design notes
* A message is also echoed to its sender, so every client shows the same **server-stamped** time.
* Read-only viewers appear in the server list as `viewer-N (read-only)`, receive all messages, but are not returned by `allUsers`.
* `OK` is always the first line a client reads; the client is added to the broadcast set only afterwards (no race).
* `send()` never calls `close()` while holding a lock (avoids a lock-order deadlock between handlers).
* Known limitation: a client that stops reading can delay the broadcasting thread (blocking writes). Fine for a mini project; a per-client outbound queue would fix it.

## Build & run

Requires **JDK 21+** and **Maven 3.9+** (JavaFX is downloaded by Maven).

```bash
mvn clean package            # in the repository root: builds both projects, runs the tests
```
This produces the executable JARs `TCPServer/target/TCPServer.jar` and `TCPClient/target/TCPClient.jar`.
They are "fat" JARs for the platform you build on (JavaFX natives are OS specific) – build on the machine that runs them.

```bash
# 1. server (reads server.properties, default 0.0.0.0:3000)
java -jar TCPServer/target/TCPServer.jar

# 2. one or more clients
java -jar TCPClient/target/TCPClient.jar localhost 3000
```
A harmless JavaFX warning about "unnamed module" may be printed when running from a fat JAR.

**IntelliJ IDEA:** open the root `pom.xml`, run `TCPServer` / `TCPClient` (set *Program arguments* `localhost 3000` for the client).

### Configuration (no recompilation)
`server.properties` (server) and `client.properties` (client; used only when no arguments are given):
```properties
server.host=0.0.0.0   # bind address (server) / server address (client)
server.port=3000
```
Lookup order: `-Dserver.config=<file>` → `./server.properties` → defaults bundled in the JAR → built-ins.
To change the port in production, drop a `server.properties` next to the JAR.

## Tests
`mvn test` runs headless tests (no GUI needed):
* `ChatServerTest` – handshake, broadcast with timestamp, duplicate names, read-only mode, `allUsers`, `bye`, abrupt disconnect, 50 concurrent clients.
* `ChatClientTest` – protocol handling against a scripted fake server, read-only, rejection, lost connection, argument parsing.

## UML (`docs/`)
| Diagram | Files |
|---|---|
| Class diagram – server | `class-diagram-server.png` / `.puml` |
| Class diagram – client | `class-diagram-client.png` / `.puml` |
| Deployment diagram | `deployment-diagram.png` / `.puml` |
| Sequence diagram (join, send, leave) | `sequence-diagram.png` / `.puml` |

![Server classes](docs/class-diagram-server.png)
![Client classes](docs/class-diagram-client.png)
![Deployment](docs/deployment-diagram.png)
![Sequence](docs/sequence-diagram.png)

The `.puml` files are PlantUML sources (IntelliJ PlantUML plugin or plantuml.com).

## Demo
`docs/DEMO_SCRIPT.md` is a 3-minute script for the walkthrough video.
