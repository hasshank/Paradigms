package com.chatapp.client.model;

import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Headless tests of the client model against a tiny scripted fake server.
 * No JavaFX is involved, which demonstrates the model/view decoupling.
 */
class ChatClientTest {

    @Test
    void connectsReceivesAndSendsAccordingToProtocol() throws Exception {
        try (FakeServer server = new FakeServer("OK|USER")) {
            Recorder recorder = new Recorder();
            ChatClient client = new ChatClient("127.0.0.1", server.port(), recorder);

            client.connect("  alice  ");
            assertFalse(client.isReadOnly());
            assertEquals("alice", client.getUsername());
            client.start();

            assertEquals("JOIN|alice", server.received());

            server.push("SYS|Welcome alice!");
            server.push("MSG|10:00:00|bob|hi\\nthere");
            server.push("USERS|alice,bob");

            assertEquals(ChatMessage.Kind.SYSTEM, recorder.messages.poll(3, TimeUnit.SECONDS).kind());
            ChatMessage chat = recorder.messages.poll(3, TimeUnit.SECONDS);
            assertEquals("bob", chat.sender());
            assertEquals("10:00:00", chat.time());
            assertEquals("hi\nthere", chat.text());
            assertEquals(List.of("alice", "bob"), recorder.users.poll(3, TimeUnit.SECONDS));

            client.sendUserInput("hello | world");
            assertEquals("MSG|hello | world", server.received());
            client.sendUserInput("allUsers");
            assertEquals("CMD|allUsers", server.received());
            client.sendUserInput("two\nlines");
            assertEquals("MSG|two\\nlines", server.received());

            client.sendUserInput("bye");
            assertEquals("BYE", server.received());
            assertEquals("You left the chat.", recorder.disconnectReason.get(3, TimeUnit.SECONDS));
            assertFalse(recorder.unexpected.get());
            assertFalse(client.isConnected());
        }
    }

    @Test
    void endAlsoLeaves() throws Exception {
        try (FakeServer server = new FakeServer("OK|USER")) {
            Recorder recorder = new Recorder();
            ChatClient client = new ChatClient("127.0.0.1", server.port(), recorder);
            client.connect("alice");
            client.start();
            server.received(); // JOIN

            client.sendUserInput("END");

            assertEquals("BYE", server.received());
            recorder.disconnectReason.get(3, TimeUnit.SECONDS);
            assertFalse(recorder.unexpected.get());
        }
    }

    @Test
    void blankUsernameJoinsReadOnlyAndNeverSendsMessages() throws Exception {
        try (FakeServer server = new FakeServer("OK|READONLY")) {
            Recorder recorder = new Recorder();
            ChatClient client = new ChatClient("127.0.0.1", server.port(), recorder);

            client.connect("   ");
            client.start();
            assertTrue(client.isReadOnly());
            assertEquals("JOIN|", server.received());

            client.sendUserInput("let me talk");

            ChatMessage notice = recorder.messages.poll(3, TimeUnit.SECONDS);
            assertEquals(ChatMessage.Kind.SYSTEM, notice.kind());
            assertTrue(notice.text().contains("READ-ONLY"));
            assertNull(server.receivedWithin(300), "nothing may reach the server");

            client.sendUserInput("bye"); // leaving is still allowed
            assertEquals("BYE", server.received());
        }
    }

    @Test
    void serverRefusalIsReportedWithItsReason() throws Exception {
        try (FakeServer server = new FakeServer("ERR|Username 'alice' is already taken")) {
            ChatClient client = new ChatClient("127.0.0.1", server.port(), new Recorder());
            ServerRejectedException e = assertThrows(ServerRejectedException.class, () -> client.connect("alice"));
            assertEquals("Username 'alice' is already taken", e.getMessage());
            assertFalse(client.isConnected());
        }
    }

    @Test
    void invalidUsernameIsRejectedBeforeAnyNetworkTraffic() {
        ChatClient client = new ChatClient("127.0.0.1", 1, new Recorder());
        assertThrows(IllegalArgumentException.class, () -> client.connect("bad|name"));
        assertThrows(IllegalArgumentException.class, () -> client.connect("x".repeat(21)));
    }

    @Test
    void unreachableServerThrowsIOException() throws Exception {
        int freePort;
        try (ServerSocket ss = new ServerSocket(0)) {
            freePort = ss.getLocalPort();
        }
        ChatClient client = new ChatClient("127.0.0.1", freePort, new Recorder());
        assertThrows(IOException.class, () -> client.connect("alice"));
    }

    @Test
    void lostConnectionIsReportedAsUnexpected() throws Exception {
        try (FakeServer server = new FakeServer("OK|USER")) {
            Recorder recorder = new Recorder();
            ChatClient client = new ChatClient("127.0.0.1", server.port(), recorder);
            client.connect("alice");
            client.start();
            server.received();

            server.dropConnection();

            recorder.disconnectReason.get(3, TimeUnit.SECONDS);
            assertTrue(recorder.unexpected.get());
            assertFalse(client.isConnected());
        }
    }

    @Test
    void configFromArguments() {
        ClientConfig config = ClientConfig.resolve(new String[]{"192.168.1.20", "4000"});
        assertEquals("192.168.1.20", config.host());
        assertEquals(4000, config.port());
        assertThrows(IllegalArgumentException.class, () -> ClientConfig.resolve(new String[]{"localhost"}));
        assertThrows(IllegalArgumentException.class, () -> ClientConfig.resolve(new String[]{"localhost", "abc"}));
        assertThrows(IllegalArgumentException.class, () -> ClientConfig.resolve(new String[]{"localhost", "70000"}));
    }

    // ------------------------------------------------------------------ helpers

    private static final class Recorder implements ClientListener {
        final BlockingQueue<ChatMessage> messages = new LinkedBlockingQueue<>();
        final BlockingQueue<List<String>> users = new LinkedBlockingQueue<>();
        final CompletableFuture<String> disconnectReason = new CompletableFuture<>();
        final java.util.concurrent.atomic.AtomicBoolean unexpected = new java.util.concurrent.atomic.AtomicBoolean();

        @Override
        public void onMessage(ChatMessage message) {
            messages.add(message);
        }

        @Override
        public void onUserList(List<String> list) {
            users.add(list);
        }

        @Override
        public void onDisconnected(String reason, boolean wasUnexpected) {
            unexpected.set(wasUnexpected);
            disconnectReason.complete(reason);
        }
    }

    /** Accepts one connection, answers the handshake with a fixed reply, then records / pushes lines. */
    private static final class FakeServer implements AutoCloseable {
        private final ServerSocket serverSocket;
        private final BlockingQueue<String> received = new LinkedBlockingQueue<>();
        private final CompletableFuture<Socket> accepted = new CompletableFuture<>();
        private volatile BufferedWriter out;

        FakeServer(String handshakeReply) throws IOException {
            serverSocket = new ServerSocket(0, 1, InetAddress.getLoopbackAddress());
            Thread.ofVirtual().start(() -> {
                try {
                    Socket socket = serverSocket.accept();
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                    out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
                    received.add(in.readLine());
                    push(handshakeReply);
                    accepted.complete(socket);
                    String line;
                    while ((line = in.readLine()) != null) {
                        received.add(line);
                    }
                } catch (IOException ignored) {
                    // test is over
                }
            });
        }

        int port() {
            return serverSocket.getLocalPort();
        }

        synchronized void push(String line) throws IOException {
            out.write(line);
            out.write('\n');
            out.flush();
        }

        String received() throws InterruptedException {
            String line = received.poll(3, TimeUnit.SECONDS);
            if (line == null) {
                throw new AssertionError("Server received nothing within 3 seconds");
            }
            return line;
        }

        String receivedWithin(long millis) throws InterruptedException {
            return received.poll(millis, TimeUnit.MILLISECONDS);
        }

        void dropConnection() throws Exception {
            accepted.get(3, TimeUnit.SECONDS).close();
        }

        @Override
        public void close() throws IOException {
            serverSocket.close();
        }
    }
}
