import com.chatapp.client.ClientApp;
import com.chatapp.client.model.ClientConfig;

/**
 * Entry point of the chat client: {@code java TCPClient <ServerIPAddress> <PortNumber>}
 * (e.g. {@code java TCPClient localhost 3000}).
 *
 * <p>When no arguments are given, host and port are read from {@code client.properties}.
 * This class does not extend {@code javafx.application.Application}, so the fat JAR runs
 * with a plain {@code java -jar}.
 */
public class TCPClient {

    public static void main(String[] args) {
        ClientConfig config;
        try {
            config = ClientConfig.resolve(args);
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
            System.err.println("Usage: java TCPClient <ServerIPAddress> <PortNumber>   (e.g. java TCPClient localhost 3000)");
            System.exit(1);
            return;
        }
        ClientApp.launchApp(config, args);
    }
}
