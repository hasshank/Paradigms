package com.chatapp.client.model;

import java.util.List;

/**
 * Observer through which {@link ChatClient} reports events, without knowing who listens.
 * Callbacks arrive on the client's reader thread (a virtual thread), never on a UI thread.
 */
public interface ClientListener {

    /** A chat message or a system notice arrived. */
    void onMessage(ChatMessage message);

    /** Reply to the {@code allUsers} command. */
    void onUserList(List<String> users);

    /**
     * The connection ended; called exactly once per connection.
     *
     * @param reason     human-readable explanation
     * @param unexpected false when the user chose to leave, true when the connection was lost
     */
    void onDisconnected(String reason, boolean unexpected);
}
