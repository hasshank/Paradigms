package com.chatapp.client.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The client model: owns the TCP connection and the protocol, and reports events through a
 * {@link ClientListener}. It has no dependency on JavaFX.
 *
 * <p>Usage: {@link #connect(String)} (blocking handshake) &rarr; {@link #start()} (begin
 * receiving) &rarr; {@link #sendUserInput(String)} ... &rarr; {@link #disconnect()}.
 * Splitting connect/start lets the UI get ready before the first events arrive.
 */
public class ChatClient {

    private static final int CONNECT_TIMEOUT_MS = 5_000;
    private static final int HANDSHAKE_TIMEOUT_MS = 5_000;

    private final String host;
    private final int port;
    private final ClientListener listener;

    private final AtomicBoolean closed = new AtomicBoolean(true);
    private final Object writeLock = new Object();

    private volatile Socket socket;
    private volatile BufferedReader in;
    private volatile BufferedWriter out;
    private volatile String username = "";
    private volatile boolean readOnly;

    public ChatClient(String host, int port, ClientListener listener) {
        this.host = host;
        this.port = port;
        this.listener = listener;
    }

    public boolean isConnected() {
        return !closed.get();
    }

    public boolean isReadOnly() {
        return readOnly;
    }

    /** The accepted username, or an empty string in READ-ONLY MODE. */
    public String getUsername() {
        return username;
    }

    // ------------------------------------------------------------------ connect / start

    /**
     * Opens the connection and performs the JOIN handshake (blocking).
     *
     * @param rawUsername the username; blank means READ-ONLY MODE
     * @throws IllegalArgumentException the username is invalid (nothing was sent)
     * @throws ServerRejectedException  the server refused the username
     * @throws IOException              the server cannot be reached
     */
    public void connect(String rawUsername) throws IOException {
        String name = rawUsername == null ? "" : rawUsername.trim();
        if (!name.isEmpty()) {
            String error = Protocol.validateUsername(name);
            if (error != null) {
                throw new IllegalArgumentException(error);
            }
        }

        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, port), CONNECT_TIMEOUT_MS);
            s.setTcpNoDelay(true);
            s.setSoTimeout(HANDSHAKE_TIMEOUT_MS);
            BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));

            writer.write(Protocol.frame(Protocol.JOIN, name));
            writer.write('\n');
            writer.flush();

            String reply = reader.readLine();
            if (reply == null) {
                throw new IOException("The server closed the connection during the handshake");
            }
            String[] parts = Protocol.split(reply, 2);
            if (Protocol.ERR.equals(parts[0])) {
                throw new ServerRejectedException(parts.length > 1 ? parts[1] : "The server refused the connection");
            }
            if (!Protocol.OK.equals(parts[0])) {
                throw new IOException("Unexpected reply from server: " + reply);
            }

            s.setSoTimeout(0);
            this.socket = s;
            this.in = reader;
            this.out = writer;
            this.username = name;
            this.readOnly = parts.length > 1 && Protocol.MODE_READONLY.equals(parts[1]);
            this.closed.set(false);
        } catch (IOException | RuntimeException e) {
            closeQuietly(s);
            throw e;
        }
    }

    /** Starts receiving messages on a virtual thread. Call once, after a successful connect. */
    public void start() {
        Thread.ofVirtual().name("chat-client-reader").start(this::readLoop);
    }

    // ------------------------------------------------------------------ sending

    /**
     * Interprets what the user typed:
     * <ul>
     *   <li>{@code end} / {@code bye} &rarr; leave the chat</li>
     *   <li>{@code allUsers} &rarr; ask the server for the active users</li>
     *   <li>anything else &rarr; a chat message (refused in READ-ONLY MODE)</li>
     * </ul>
     *
     * @throws IllegalArgumentException message too long
     * @throws IOException              the connection is gone
     */
    public void sendUserInput(String input) throws IOException {
        if (closed.get()) {
            throw new IOException("Not connected");
        }
        String text = input == null ? "" : input.strip();
        if (text.isEmpty()) {
            return;
        }

        if (text.equalsIgnoreCase("end") || text.equalsIgnoreCase("bye")) {
            disconnect();
            return;
        }
        if (readOnly) {
            listener.onMessage(ChatMessage.system("READ-ONLY MODE: you cannot send messages."));
            return;
        }
        if (text.equalsIgnoreCase(Protocol.CMD_ALL_USERS)) {
            send(Protocol.frame(Protocol.CMD, Protocol.CMD_ALL_USERS));
            return;
        }
        if (text.length() > Protocol.MAX_TEXT) {
            throw new IllegalArgumentException("Message too long (max " + Protocol.MAX_TEXT + " characters)");
        }
        send(Protocol.frame(Protocol.MSG, Protocol.escape(text)));
    }

    /** Leaves the chat: tells the server ("BYE"), closes the connection and notifies the listener. */
    public void disconnect() {
        if (closed.get()) {
            return;
        }
        try {
            rawWrite(Protocol.frame(Protocol.BYE));
        } catch (IOException ignored) {
            // closing anyway
        }
        shutdown("You left the chat.", false);
    }

    private void send(String frame) throws IOException {
        try {
            rawWrite(frame);
        } catch (IOException e) {
            shutdown("Connection lost: " + e.getMessage(), true);
            throw e;
        }
    }

    private void rawWrite(String frame) throws IOException {
        synchronized (writeLock) {
            out.write(frame);
            out.write('\n');
            out.flush();
        }
    }

    // ------------------------------------------------------------------ receiving

    private void readLoop() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                handle(line);
            }
            shutdown("The server closed the connection.", true);
        } catch (IOException e) {
            if (!closed.get()) {
                shutdown("Connection lost: " + e.getMessage(), true);
            }
        }
    }

    private void handle(String line) {
        String[] head = Protocol.split(line, 2);
        String body = head.length > 1 ? head[1] : "";

        switch (head[0]) {
            case Protocol.MSG -> {
                String[] fields = Protocol.split(body, 3);
                if (fields.length == 3) {
                    listener.onMessage(ChatMessage.chat(fields[0], fields[1], Protocol.unescape(fields[2])));
                }
            }
            case Protocol.SYS -> listener.onMessage(ChatMessage.system(Protocol.unescape(body)));
            case Protocol.USERS -> listener.onUserList(body.isEmpty() ? List.of() : List.of(body.split(",")));
            default -> {
                // unknown frame types are ignored for forward compatibility
            }
        }
    }

    private void shutdown(String reason, boolean unexpected) {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        closeQuietly(socket);
        listener.onDisconnected(reason, unexpected);
    }

    private static void closeQuietly(Socket s) {
        if (s != null) {
            try {
                s.close();
            } catch (IOException ignored) {
                // nothing more to do
            }
        }
    }
}
