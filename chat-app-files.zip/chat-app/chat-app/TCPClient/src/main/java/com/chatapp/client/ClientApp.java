package com.chatapp.client;

import com.chatapp.client.controller.ClientController;
import com.chatapp.client.model.ClientConfig;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/** JavaFX application: creates the window and hands control to the {@link ClientController}. */
public class ClientApp extends Application {

    private static ClientConfig config;

    private ClientController controller;

    public static void launchApp(ClientConfig clientConfig, String[] args) {
        config = clientConfig;
        launch(ClientApp.class, args);
    }

    @Override
    public void start(Stage stage) {
        Scene scene = new Scene(new StackPane(), 880, 660);
        scene.getStylesheets().add(getClass().getResource("/css/client.css").toExternalForm());
        controller = new ClientController(config, scene);

        stage.setTitle("Group Chat — " + config.endpoint());
        stage.setMinWidth(560);
        stage.setMinHeight(480);
        stage.setScene(scene);
        stage.setOnCloseRequest(e -> controller.shutdown());
        stage.show();
    }

    @Override
    public void stop() {
        if (controller != null) {
            controller.shutdown();
        }
    }
}
