package com.chatapp.client.model;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Where to find the server.
 *
 * <p>Command-line arguments {@code <ServerIPAddress> <PortNumber>} win. Without arguments the
 * values come from {@code client.properties} (working directory, or {@code -Dclient.config=...},
 * or the default bundled in the JAR), and finally from the built-in default localhost:3000.
 */
public record ClientConfig(String host, int port, String source) {

    public static final String DEFAULT_HOST = "localhost";
    public static final int DEFAULT_PORT = 3000;

    public ClientConfig {
        if (host == null || host.isBlank()) {
            throw new IllegalArgumentException("Server address must not be empty");
        }
        if (port < 1 || port > 65535) {
            throw new IllegalArgumentException("Port must be between 1 and 65535 (was " + port + ")");
        }
    }

    public String endpoint() {
        return host + ":" + port;
    }

    /** @throws IllegalArgumentException if the arguments are malformed */
    public static ClientConfig resolve(String[] args) {
        if (args.length == 0) {
            return loadFromFile();
        }
        if (args.length != 2) {
            throw new IllegalArgumentException("expected exactly 2 arguments but got " + args.length);
        }
        return new ClientConfig(args[0].trim(), parsePort(args[1]), "command line");
    }

    static ClientConfig loadFromFile() {
        Properties props = new Properties();
        String source = "built-in defaults";

        String override = System.getProperty("client.config");
        Path external = Path.of(override != null ? override : "client.properties");

        try {
            if (Files.isRegularFile(external)) {
                try (Reader reader = Files.newBufferedReader(external, StandardCharsets.UTF_8)) {
                    props.load(reader);
                }
                source = external.toAbsolutePath().toString();
            } else {
                try (InputStream in = ClientConfig.class.getResourceAsStream("/client.properties")) {
                    if (in != null) {
                        props.load(in);
                        source = "classpath:/client.properties";
                    }
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read client configuration", e);
        }

        return new ClientConfig(
                props.getProperty("server.host", DEFAULT_HOST).trim(),
                parsePort(props.getProperty("server.port", String.valueOf(DEFAULT_PORT))),
                source);
    }

    private static int parsePort(String raw) {
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("port is not a number: '" + raw + "'");
        }
    }
}
