package com.chatapp.client.view;

import com.chatapp.client.model.ChatMessage;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.util.function.Consumer;

/**
 * The chat screen (GridPane layout + CSS): header with the Online indicator and LEAVE button,
 * the conversation, and the message composer. Pure presentation, no networking: user actions
 * are reported through callbacks. All methods must be called on the JavaFX Application Thread.
 */
public class ChatView {

    private static final String GREEN = "#22c55e";
    private static final String RED = "#ef4444";

    private final GridPane root = new GridPane();
    private final ObservableList<ChatMessage> messages = FXCollections.observableArrayList();
    private final ListView<ChatMessage> messageList = new ListView<>(messages);
    private final TextArea inputArea = new TextArea();
    private final Button sendButton = new Button("SEND");
    private final Button leaveButton = new Button("LEAVE");
    private final Circle statusDot = new Circle(6);
    private final Label statusLabel = new Label("Online");

    private final String username;
    private final boolean readOnly;

    private Consumer<String> sendHandler = text -> { };

    public ChatView(String username, boolean readOnly, String endpoint) {
        this.username = username;
        this.readOnly = readOnly;
        root.getStyleClass().add("chat-root");

        ColumnConstraints column = new ColumnConstraints();
        column.setHgrow(Priority.ALWAYS);
        root.getColumnConstraints().add(column);

        RowConstraints headerRow = new RowConstraints();
        RowConstraints bannerRow = new RowConstraints();
        RowConstraints listRow = new RowConstraints();
        listRow.setVgrow(Priority.ALWAYS);
        RowConstraints composerRow = new RowConstraints();
        RowConstraints hintRow = new RowConstraints();
        root.getRowConstraints().addAll(headerRow, bannerRow, listRow, composerRow, hintRow);

        root.add(buildHeader(endpoint), 0, 0);
        root.add(buildBanner(), 0, 1);
        configureMessageList();
        root.add(messageList, 0, 2);
        root.add(buildComposer(), 0, 3);
        root.add(buildHint(), 0, 4);

        setConnected(true);
    }

    public Parent getRoot() {
        return root;
    }

    // ------------------------------------------------------------------ API used by the controller

    public void onSend(Consumer<String> handler) {
        this.sendHandler = handler;
    }

    public void onLeave(Runnable action) {
        leaveButton.setOnAction(e -> action.run());
    }

    public void addMessage(ChatMessage message) {
        messages.add(message);
        Platform.runLater(() -> messageList.scrollTo(messages.size() - 1));
    }

    /** Switches the Online/Offline indicator and enables or disables the composer accordingly. */
    public void setConnected(boolean connected) {
        statusDot.setFill(Color.web(connected ? GREEN : RED));
        statusLabel.setText(connected ? "Online" : "Offline");
        boolean canType = connected && !readOnly;
        inputArea.setDisable(!canType);
        sendButton.setDisable(!canType);
    }

    public void focusInput() {
        if (!readOnly) {
            Platform.runLater(inputArea::requestFocus);
        }
    }

    // ------------------------------------------------------------------ layout

    private GridPane buildHeader(String endpoint) {
        Label title = new Label("Group Chat");
        title.getStyleClass().add("app-title");
        String who = readOnly ? "Guest (read-only)" : "Signed in as " + username;
        Label subtitle = new Label(who + "  ·  " + endpoint);
        subtitle.getStyleClass().add("subtitle");
        VBox titleBox = new VBox(2, title, subtitle);

        statusLabel.getStyleClass().add("status-label");
        HBox statusBox = new HBox(8, statusDot, statusLabel);
        statusBox.setAlignment(Pos.CENTER);

        leaveButton.getStyleClass().add("danger-button");

        GridPane header = new GridPane();
        header.getStyleClass().add("chat-header");
        header.setHgap(18);
        ColumnConstraints grow = new ColumnConstraints();
        grow.setHgrow(Priority.ALWAYS);
        header.getColumnConstraints().addAll(grow, new ColumnConstraints(), new ColumnConstraints());
        header.add(titleBox, 0, 0);
        header.add(statusBox, 1, 0);
        header.add(leaveButton, 2, 0);
        GridPane.setValignment(statusBox, VPos.CENTER);
        GridPane.setValignment(leaveButton, VPos.CENTER);
        return header;
    }

    private Label buildBanner() {
        Label banner = new Label("READ-ONLY MODE — you can follow the conversation but cannot send messages. "
                + "Leave and rejoin with a username to take part.");
        banner.getStyleClass().add("readonly-banner");
        banner.setWrapText(true);
        banner.setMaxWidth(Double.MAX_VALUE);
        banner.setVisible(readOnly);
        banner.setManaged(readOnly);
        return banner;
    }

    private GridPane buildComposer() {
        inputArea.setPromptText(readOnly
                ? "READ-ONLY MODE — sending is disabled"
                : "Type a message…");
        inputArea.setPrefRowCount(2);
        inputArea.setWrapText(true);
        // Enter sends; Shift+Enter inserts a new line.
        inputArea.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.ENTER) {
                e.consume();
                if (e.isShiftDown()) {
                    inputArea.insertText(inputArea.getCaretPosition(), "\n");
                } else {
                    submit();
                }
            }
        });

        sendButton.getStyleClass().add("primary-button");
        sendButton.setMaxHeight(Double.MAX_VALUE);
        sendButton.setOnAction(e -> submit());

        GridPane composer = new GridPane();
        composer.getStyleClass().add("composer");
        composer.setHgap(10);
        ColumnConstraints grow = new ColumnConstraints();
        grow.setHgrow(Priority.ALWAYS);
        composer.getColumnConstraints().addAll(grow, new ColumnConstraints());
        composer.add(inputArea, 0, 0);
        composer.add(sendButton, 1, 0);
        GridPane.setHgrow(inputArea, Priority.ALWAYS);
        return composer;
    }

    private Label buildHint() {
        Label hint = new Label(readOnly
                ? "Read-only: end / bye or LEAVE disconnects."
                : "Enter = send  ·  Shift+Enter = new line  ·  allUsers = list active users  ·  end / bye = leave");
        hint.getStyleClass().add("hint");
        GridPane.setMargin(hint, new Insets(0, 16, 10, 16));
        GridPane.setHalignment(hint, HPos.LEFT);
        return hint;
    }

    private void submit() {
        String text = inputArea.getText().strip();
        if (text.isEmpty()) {
            return;
        }
        inputArea.clear();
        sendHandler.accept(text);
    }

    // ------------------------------------------------------------------ message list

    private void configureMessageList() {
        messageList.getStyleClass().add("chat-list");
        messageList.setPlaceholder(new Label("No messages yet"));
        messageList.setFocusTraversable(false);
        messageList.setCellFactory(lv -> new MessageCell());
    }

    /** Renders one conversation entry as a bubble: mine on the right, others on the left, notices centred. */
    private final class MessageCell extends ListCell<ChatMessage> {

        private final Label senderLabel = new Label();
        private final Label bodyLabel = new Label();
        private final Label timeLabel = new Label();
        private final VBox bubble = new VBox(2, senderLabel, bodyLabel, timeLabel);
        private final HBox row = new HBox(bubble);

        MessageCell() {
            setPrefWidth(0); // never force a horizontal scrollbar; wrap instead
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            // A cell does not stretch its graphic, so give the row the full width to make the
            // left / right / centre alignment of the bubbles work.
            row.prefWidthProperty().bind(messageList.widthProperty().subtract(48));
            senderLabel.getStyleClass().add("msg-sender");
            bodyLabel.getStyleClass().add("msg-body");
            timeLabel.getStyleClass().add("msg-time");
            bodyLabel.setWrapText(true);
            bodyLabel.setMinHeight(Region.USE_PREF_SIZE);
            bubble.maxWidthProperty().bind(messageList.widthProperty().multiply(0.72));
            bodyLabel.maxWidthProperty().bind(bubble.maxWidthProperty().subtract(28));
            timeLabel.setMaxWidth(Double.MAX_VALUE);
            timeLabel.setAlignment(Pos.CENTER_RIGHT);
        }

        @Override
        protected void updateItem(ChatMessage message, boolean empty) {
            super.updateItem(message, empty);
            if (empty || message == null) {
                setGraphic(null);
                setText(null);
                return;
            }

            bodyLabel.setText(message.text());
            if (message.kind() == ChatMessage.Kind.SYSTEM) {
                bubble.getStyleClass().setAll("msg-system");
                row.setAlignment(Pos.CENTER);
                setVisibleManaged(senderLabel, false);
                setVisibleManaged(timeLabel, false);
            } else {
                boolean mine = !readOnly && message.sender().equals(username);
                bubble.getStyleClass().setAll("bubble", mine ? "bubble-own" : "bubble-other");
                row.setAlignment(mine ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
                senderLabel.setText(mine ? "You" : message.sender());
                timeLabel.setText(message.time());
                setVisibleManaged(senderLabel, true);
                setVisibleManaged(timeLabel, true);
            }
            setText(null);
            setGraphic(row);
        }

        private void setVisibleManaged(Label label, boolean show) {
            label.setVisible(show);
            label.setManaged(show);
        }
    }
}
