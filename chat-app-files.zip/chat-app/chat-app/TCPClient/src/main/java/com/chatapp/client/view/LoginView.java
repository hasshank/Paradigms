package com.chatapp.client.view;

import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

import java.util.function.Consumer;

/**
 * The first screen: the user enters a username before reaching the chat.
 * Leaving the field empty joins in READ-ONLY MODE. Pure presentation, no networking.
 */
public class LoginView {

    private final GridPane root = new GridPane();
    private final TextField usernameField = new TextField();
    private final Button connectButton = new Button();
    private final Label messageLabel = new Label();
    private Consumer<String> connectHandler = name -> { };

    public LoginView(String endpoint) {
        root.getStyleClass().add("login-root");
        root.setAlignment(Pos.CENTER);

        Label title = new Label("Group Chat");
        title.getStyleClass().add("app-title");
        Label server = new Label("Server: " + endpoint);
        server.getStyleClass().add("subtitle");

        Label usernameLabel = new Label("Username");
        usernameLabel.getStyleClass().add("field-label");

        usernameField.setPromptText("Choose a username");
        usernameField.setTextFormatter(new TextFormatter<String>(change ->
                change.getControlNewText().length() <= 20 ? change : null));

        Label hint = new Label("No username? Leave the field empty to join in READ-ONLY MODE: "
                + "you will see the conversation but cannot send messages.");
        hint.getStyleClass().add("hint");
        hint.setWrapText(true);

        connectButton.getStyleClass().add("primary-button");
        connectButton.setMaxWidth(Double.MAX_VALUE);
        connectButton.setDefaultButton(true);
        connectButton.textProperty().bind(Bindings.createStringBinding(
                () -> usernameField.getText().isBlank() ? "Join in READ-ONLY MODE" : "Join chat",
                usernameField.textProperty()));
        connectButton.setOnAction(e -> connectHandler.accept(usernameField.getText()));

        messageLabel.setWrapText(true);

        GridPane card = new GridPane();
        card.getStyleClass().add("card");
        card.setVgap(10);
        card.setPrefWidth(400);
        card.setMaxWidth(400);
        card.setMaxHeight(GridPane.USE_PREF_SIZE);
        GridPane.setHgrow(usernameField, Priority.ALWAYS);

        card.add(title, 0, 0);
        card.add(server, 0, 1);
        card.add(usernameLabel, 0, 2);
        card.add(usernameField, 0, 3);
        card.add(hint, 0, 4);
        card.add(connectButton, 0, 5);
        card.add(messageLabel, 0, 6);
        GridPane.setMargin(usernameLabel, new javafx.geometry.Insets(12, 0, 0, 0));
        GridPane.setHgrow(hint, Priority.ALWAYS);
        GridPane.setHgrow(connectButton, Priority.ALWAYS);

        javafx.scene.layout.ColumnConstraints column = new javafx.scene.layout.ColumnConstraints();
        column.setHgrow(Priority.ALWAYS);
        card.getColumnConstraints().add(column);

        root.add(card, 0, 0);
    }

    public Parent getRoot() {
        return root;
    }

    public void onConnect(Consumer<String> handler) {
        this.connectHandler = handler;
    }

    /** Disables the form while a connection attempt is in progress. */
    public void setBusy(boolean busy) {
        usernameField.setDisable(busy);
        connectButton.setDisable(busy);
    }

    public void showMessage(String text, boolean error) {
        messageLabel.setText(text);
        messageLabel.getStyleClass().removeAll("msg-error", "msg-info");
        messageLabel.getStyleClass().add(error ? "msg-error" : "msg-info");
    }

    public void focusUsername() {
        Platform.runLater(usernameField::requestFocus);
    }
}
