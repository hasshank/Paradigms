package com.chatapp.client.model;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * One entry of the conversation: either a chat message from a user or a system notice.
 *
 * @param time   HH:mm:ss, stamped by the server for chat messages
 * @param sender username (empty for system notices)
 */
public record ChatMessage(Kind kind, String time, String sender, String text) {

    public enum Kind { CHAT, SYSTEM }

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    public static ChatMessage chat(String time, String sender, String text) {
        return new ChatMessage(Kind.CHAT, time, sender, text);
    }

    public static ChatMessage system(String text) {
        return new ChatMessage(Kind.SYSTEM, LocalTime.now().format(TIME), "", text);
    }
}
