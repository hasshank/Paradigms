package com.chatapp.client.model;

import java.io.IOException;

/** The server was reachable but refused the join request (e.g. username already taken). */
public class ServerRejectedException extends IOException {

    private static final long serialVersionUID = 1L;

    public ServerRejectedException(String message) {
        super(message);
    }
}
