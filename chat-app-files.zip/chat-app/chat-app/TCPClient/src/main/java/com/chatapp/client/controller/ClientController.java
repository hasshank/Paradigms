package com.chatapp.client.controller;

import com.chatapp.client.model.ChatClient;
import com.chatapp.client.model.ChatMessage;
import com.chatapp.client.model.ClientConfig;
import com.chatapp.client.model.ClientListener;
import com.chatapp.client.model.ServerRejectedException;
import com.chatapp.client.view.ChatView;
import com.chatapp.client.view.LoginView;
import javafx.application.Platform;
import javafx.scene.Scene;

import java.io.IOException;
import java.util.List;

/**
 * Glue between the model ({@link ChatClient}) and the two views. It reacts to user actions
 * coming from the views and to network events coming from the model; the latter arrive on a
 * background thread and are marshalled to the JavaFX thread here.
 */
public class ClientController implements ClientListener {

    private final ClientConfig config;
    private final Scene scene;
    private final LoginView loginView;

    private ChatView chatView;
    private ChatClient client;

    public ClientController(ClientConfig config, Scene scene) {
        this.config = config;
        this.scene = scene;
        this.loginView = new LoginView(config.endpoint());
        this.loginView.onConnect(this::connect);
        showLogin(null, false);
    }

    /** Called when the window is closed: leaves the chat so the server is notified. */
    public void shutdown() {
        if (client != null) {
            client.disconnect();
        }
    }

    // ------------------------------------------------------------------ login

    private void connect(String username) {
        loginView.setBusy(true);
        loginView.showMessage("Connecting to " + config.endpoint() + "…", false);

        ChatClient candidate = new ChatClient(config.host(), config.port(), this);
        Thread.ofVirtual().start(() -> {
            try {
                candidate.connect(username);
                Platform.runLater(() -> enterChat(candidate));
            } catch (IllegalArgumentException | ServerRejectedException e) {
                Platform.runLater(() -> failLogin(e.getMessage()));
            } catch (IOException e) {
                Platform.runLater(() -> failLogin("Cannot reach the server at " + config.endpoint()
                        + " (" + e.getMessage() + ")"));
            }
        });
    }

    private void failLogin(String message) {
        loginView.setBusy(false);
        loginView.showMessage(message, true);
        loginView.focusUsername();
    }

    private void enterChat(ChatClient connected) {
        client = connected;
        chatView = new ChatView(connected.getUsername(), connected.isReadOnly(), config.endpoint());
        chatView.onSend(this::handleSend);
        chatView.onLeave(this::handleLeave);
        scene.setRoot(chatView.getRoot());
        chatView.focusInput();
        connected.start(); // only now: the UI is ready for the first events
    }

    private void showLogin(String message, boolean error) {
        chatView = null;
        client = null;
        loginView.setBusy(false);
        if (message == null) {
            loginView.showMessage("", false);
        } else {
            loginView.showMessage(message, error);
        }
        scene.setRoot(loginView.getRoot());
        loginView.focusUsername();
    }

    // ------------------------------------------------------------------ chat actions

    private void handleSend(String text) {
        try {
            client.sendUserInput(text);
        } catch (IllegalArgumentException e) {
            chatView.addMessage(ChatMessage.system(e.getMessage()));
        } catch (IOException e) {
            // the model already reported the lost connection through onDisconnected
        }
    }

    private void handleLeave() {
        if (client != null && client.isConnected()) {
            client.disconnect(); // -> onDisconnected(...) -> back to the login screen
        } else {
            showLogin(null, false); // already offline: just go back
        }
    }

    // ------------------------------------------------------------------ ClientListener (background thread)

    @Override
    public void onMessage(ChatMessage message) {
        Platform.runLater(() -> {
            if (chatView != null) {
                chatView.addMessage(message);
            }
        });
    }

    @Override
    public void onUserList(List<String> users) {
        onMessage(ChatMessage.system("Active users (" + users.size() + "): " + String.join(", ", users)));
    }

    @Override
    public void onDisconnected(String reason, boolean unexpected) {
        Platform.runLater(() -> {
            if (chatView == null) {
                return;
            }
            if (unexpected) {
                // Stay on the chat screen, show Offline, and let the user press LEAVE to go back.
                chatView.setConnected(false);
                chatView.addMessage(ChatMessage.system(reason));
            } else {
                showLogin(reason, false);
            }
        });
    }
}
