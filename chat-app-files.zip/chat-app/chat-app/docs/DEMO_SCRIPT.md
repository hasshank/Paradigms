# 3-minute demo script

**0:00 – Code walkthrough (≈75 s)**
1. Show the two Maven projects and the `model` / `view` / `controller` packages. Point out that `model` has no JavaFX imports.
2. `ChatServer`: accept loop + `Executors.newVirtualThreadPerTaskExecutor()` (one virtual thread per client), `broadcastChat` (adds username + time).
3. `ClientHandler`: JOIN handshake, read-only check, `allUsers`, `BYE`.
4. `ChatClient`: `sendUserInput` (end/bye/allUsers), reader virtual thread.
5. `server.properties` – change the port without recompiling.

**1:15 – Live demo (≈105 s)**
1. `java -jar TCPServer.jar` → log shows *Server Started*, *Waiting for Client*.
2. Start three clients: `java -jar TCPClient.jar localhost 3000`.
   * Client 1: username `alice` → "Online" + green circle; server logs *Welcome alice*, user appears in coloured list.
   * Client 2: `bob`.
   * Client 3: leave the username empty → **READ-ONLY MODE** banner, input disabled.
3. alice sends a message with Enter, bob with SEND; all three see name + time; read-only client only reads.
4. bob types `allUsers` → list appears only for bob.
5. Try a duplicate username → error on the login screen.
6. bob types `bye` (or LEAVE) → back to login; server list/log update, alice sees "bob left the chat".
7. Stop the server → clients show *Offline* (red circle).
