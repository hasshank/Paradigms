package com.chatapp.server.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Serves one connected client on its own (virtual) thread: performs the JOIN handshake, then
 * reads requests line by line until the client leaves or the connection drops.
 */
final class ClientHandler implements Runnable {

    private static final int HANDSHAKE_TIMEOUT_MS = 15_000;

    private final ChatServer server;
    private final Socket socket;
    private final BufferedReader in;
    private final BufferedWriter out;
    private final AtomicBoolean closed = new AtomicBoolean(false);
    private final String remote;

    private volatile String displayName = "unknown";
    private volatile boolean readOnly;
    private volatile boolean reserved;

    ClientHandler(ChatServer server, Socket socket) throws IOException {
        this.server = server;
        this.socket = socket;
        this.remote = String.valueOf(socket.getRemoteSocketAddress());
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        this.out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
    }

    String displayName() {
        return displayName;
    }

    boolean isReadOnly() {
        return readOnly;
    }

    boolean isReserved() {
        return reserved;
    }

    String remoteAddress() {
        return remote;
    }

    @Override
    public void run() {
        try {
            socket.setSoTimeout(HANDSHAKE_TIMEOUT_MS);
            if (!handshake()) {
                return;
            }
            socket.setSoTimeout(0);
            String line;
            while ((line = in.readLine()) != null) {
                if (!process(line)) {
                    break;
                }
            }
        } catch (SocketTimeoutException e) {
            server.log("Handshake timed out for " + remote);
        } catch (IOException e) {
            if (!closed.get()) {
                server.log("Connection with " + displayName + " lost: " + e.getMessage());
            }
        } finally {
            close();
        }
    }

    /** First line must be {@code JOIN|<username>}; a blank username means READ-ONLY MODE. */
    private boolean handshake() throws IOException {
        String line = in.readLine();
        if (line == null) {
            return false;
        }
        String[] parts = Protocol.split(line, 2);
        if (!Protocol.JOIN.equals(parts[0]) || parts.length < 2) {
            send(Protocol.frame(Protocol.ERR, "Expected JOIN handshake"));
            return false;
        }

        String name = parts[1].trim();
        if (name.isEmpty()) {
            readOnly = true;
            displayName = server.nextViewerName();
        } else {
            String error = Protocol.validateUsername(name);
            if (error != null) {
                send(Protocol.frame(Protocol.ERR, error));
                return false;
            }
            displayName = name;
            if (!server.reserveName(this)) {
                send(Protocol.frame(Protocol.ERR, "Username '" + name + "' is already taken"));
                return false;
            }
            reserved = true;
        }

        // "OK" must be the first thing the client reads, so announce the client only afterwards.
        send(Protocol.frame(Protocol.OK, readOnly ? Protocol.MODE_READONLY : Protocol.MODE_USER));
        server.activate(this);
        return true;
    }

    /** @return false when the connection should be closed */
    private boolean process(String line) {
        String[] parts = Protocol.split(line, 2);
        String body = parts.length > 1 ? parts[1] : "";

        switch (parts[0]) {
            case Protocol.MSG -> {
                if (readOnly) {
                    send(Protocol.frame(Protocol.SYS, "READ-ONLY MODE: you cannot send messages."));
                } else if (body.isBlank()) {
                    // ignore empty messages
                } else if (body.length() > Protocol.MAX_TEXT) {
                    send(Protocol.frame(Protocol.SYS, "Message too long (max " + Protocol.MAX_TEXT + " characters)."));
                } else {
                    server.broadcastChat(this, body);
                }
            }
            case Protocol.CMD -> {
                if (Protocol.CMD_ALL_USERS.equalsIgnoreCase(body.trim())) {
                    send(Protocol.frame(Protocol.USERS, String.join(",", server.getConnectedUsers())));
                } else {
                    send(Protocol.frame(Protocol.SYS, "Unknown command: " + body));
                }
            }
            case Protocol.BYE -> {
                return false;
            }
            default -> send(Protocol.frame(Protocol.SYS, "Unknown request"));
        }
        return true;
    }

    /** Thread-safe write of one frame. A failed write closes this connection. */
    void send(String frame) {
        boolean failed = false;
        synchronized (out) {
            try {
                out.write(frame);
                out.write('\n');
                out.flush();
            } catch (IOException e) {
                failed = true;
            }
        }
        // close() outside the lock: it may broadcast, which locks other handlers (deadlock risk).
        if (failed) {
            close();
        }
    }

    void close() {
        if (closed.compareAndSet(false, true)) {
            try {
                socket.close();
            } catch (IOException ignored) {
                // nothing more to do
            }
            server.release(this);
        }
    }
}
