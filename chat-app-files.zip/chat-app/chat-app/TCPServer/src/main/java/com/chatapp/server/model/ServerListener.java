package com.chatapp.server.model;

/**
 * Observer through which the model reports what happens, without knowing who listens
 * (a JavaFX view, a console logger, a unit test...).
 *
 * <p>Callbacks are invoked from server threads (virtual threads), never from a UI thread;
 * a GUI implementation must hop to its own thread before touching controls.
 */
public interface ServerListener {

    /** A line for the activity log ("Server Started", "Waiting for Client", ...). */
    void onLog(String message);

    /** A client finished its handshake. {@code displayName} is a username or "viewer-N (read-only)". */
    void onUserJoined(String displayName);

    /** A previously announced client disconnected. */
    void onUserLeft(String displayName);
}
