package com.chatapp.server;

import com.chatapp.server.controller.ServerController;
import com.chatapp.server.model.ServerConfig;
import com.chatapp.server.view.ServerView;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;

/** JavaFX application: wires model, view and controller together and shows the server window. */
public class ServerApp extends Application {

    private ServerController controller;

    public static void launchApp(String[] args) {
        launch(ServerApp.class, args);
    }

    @Override
    public void start(Stage stage) {
        ServerConfig config;
        try {
            config = ServerConfig.load();
        } catch (RuntimeException e) {
            System.err.println("Invalid server configuration: " + e.getMessage());
            Platform.exit();
            return;
        }

        ServerView view = new ServerView();
        controller = new ServerController(config, view);

        Scene scene = new Scene(view.getRoot(), 900, 580);
        scene.getStylesheets().add(getClass().getResource("/css/server.css").toExternalForm());

        stage.setTitle("TCP Chat Server");
        stage.setMinWidth(720);
        stage.setMinHeight(440);
        stage.setScene(scene);
        stage.setOnCloseRequest(e -> controller.shutdown());
        stage.show();

        controller.start();
    }

    @Override
    public void stop() {
        if (controller != null) {
            controller.shutdown();
        }
    }
}
