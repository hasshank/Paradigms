package com.chatapp.server.model;

import java.util.regex.Pattern;

/**
 * Line-based text protocol shared (by convention) with the client project.
 *
 * <pre>
 * client -> server            server -> client
 * JOIN|&lt;username&gt;  (blank = read-only)   OK|USER  |  OK|READONLY  |  ERR|&lt;reason&gt;
 * MSG|&lt;escaped text&gt;                     MSG|&lt;HH:mm:ss&gt;|&lt;sender&gt;|&lt;escaped text&gt;
 * CMD|allUsers                          USERS|name1,name2,...
 * BYE                                   SYS|&lt;system notice&gt;
 * </pre>
 *
 * Every frame is one UTF-8 line. Newlines inside chat text are escaped as {@code \n}.
 * This class contains no UI code.
 */
public final class Protocol {

    private Protocol() {
    }

    public static final String SEP = "|";

    // client -> server
    public static final String JOIN = "JOIN";
    public static final String MSG = "MSG";
    public static final String CMD = "CMD";
    public static final String BYE = "BYE";

    // server -> client
    public static final String OK = "OK";
    public static final String ERR = "ERR";
    public static final String SYS = "SYS";
    public static final String USERS = "USERS";

    public static final String MODE_USER = "USER";
    public static final String MODE_READONLY = "READONLY";

    public static final String CMD_ALL_USERS = "allUsers";

    public static final int MAX_USERNAME = 20;
    public static final int MAX_TEXT = 2000;

    private static final Pattern USERNAME = Pattern.compile("[\\p{L}\\p{N}_.\\- ]+");

    /** Builds a frame such as {@code MSG|12:00:00|alice|hi}. */
    public static String frame(String type, String... fields) {
        StringBuilder sb = new StringBuilder(type);
        for (String field : fields) {
            sb.append(SEP).append(field);
        }
        return sb.toString();
    }

    /** Splits a frame into at most {@code limit} parts (the last part keeps any extra separators). */
    public static String[] split(String line, int limit) {
        return line.split("\\|", limit);
    }

    /** @return an error message, or {@code null} if the (already trimmed) username is acceptable. */
    public static String validateUsername(String name) {
        if (name == null || name.isBlank()) {
            return "Username must not be empty";
        }
        if (name.length() > MAX_USERNAME) {
            return "Username is too long (max " + MAX_USERNAME + " characters)";
        }
        if (!USERNAME.matcher(name).matches()) {
            return "Username may only contain letters, digits, spaces, '_', '-' and '.'";
        }
        return null;
    }

    public static String escape(String text) {
        return text.replace("\r\n", "\n").replace('\r', '\n')
                .replace("\\", "\\\\").replace("\n", "\\n");
    }

    public static String unescape(String text) {
        StringBuilder sb = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\\' && i + 1 < text.length()) {
                char next = text.charAt(++i);
                sb.append(next == 'n' ? '\n' : next);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
