package com.chatapp.server.view;

import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Pure presentation of the server window (GridPane layout + CSS). It knows nothing about sockets:
 * a controller pushes data in and receives button clicks through callbacks.
 * All methods must be called on the JavaFX Application Thread.
 */
public class ServerView {

    private static final String GREEN = "#22c55e";
    private static final String RED = "#ef4444";

    private final GridPane root = new GridPane();
    private final ObservableList<String> users = FXCollections.observableArrayList();
    private final ObservableList<String> logLines = FXCollections.observableArrayList();
    private final Map<String, String> userColors = new HashMap<>();
    private final Random random = new Random();

    private final Circle statusDot = new Circle(6);
    private final Label statusLabel = new Label("Stopped");
    private final Label endpointLabel = new Label();
    private final Label countLabel = new Label();
    private final ListView<String> userList = new ListView<>(users);
    private final ListView<String> logList = new ListView<>(logLines);
    private final Button toggleButton = new Button("Stop Server");
    private final Button clearButton = new Button("Clear log");

    public ServerView() {
        root.getStyleClass().add("server-root");

        ColumnConstraints left = new ColumnConstraints();
        left.setPercentWidth(34);
        ColumnConstraints right = new ColumnConstraints();
        right.setPercentWidth(66);
        root.getColumnConstraints().addAll(left, right);

        RowConstraints header = new RowConstraints();
        RowConstraints titles = new RowConstraints();
        RowConstraints body = new RowConstraints();
        body.setVgrow(Priority.ALWAYS);
        RowConstraints footer = new RowConstraints();
        root.getRowConstraints().addAll(header, titles, body, footer);

        configureLists();

        root.add(buildHeader(), 0, 0, 2, 1);
        root.add(sectionTitle("Connected users"), 0, 1);
        root.add(sectionTitle("Activity log"), 1, 1);
        root.add(userList, 0, 2);
        root.add(logList, 1, 2);
        root.add(buildFooter(), 0, 3, 2, 1);

        GridPane.setMargin(userList, new Insets(0, 8, 0, 16));
        GridPane.setMargin(logList, new Insets(0, 16, 0, 8));

        countLabel.textProperty().bind(Bindings.size(users).asString().concat(" connected"));
        setRunning(false, "");
    }

    public Parent getRoot() {
        return root;
    }

    // ------------------------------------------------------------------ API used by the controller

    public void setRunning(boolean running, String endpoint) {
        statusDot.setFill(Color.web(running ? GREEN : RED));
        statusLabel.setText(running ? "Running" : "Stopped");
        endpointLabel.setText(running ? "Listening on " + endpoint : "Not listening");
        toggleButton.setText(running ? "Stop Server" : "Start Server");
    }

    public void appendLog(String line) {
        logLines.add(line);
        Platform.runLater(() -> logList.scrollTo(logLines.size() - 1));
    }

    public void addUser(String name) {
        if (!users.contains(name)) {
            users.add(name);
        }
    }

    public void removeUser(String name) {
        users.remove(name);
        userColors.remove(name);
    }

    public void clearUsers() {
        users.clear();
        userColors.clear();
    }

    public void onToggle(Runnable action) {
        toggleButton.setOnAction(e -> action.run());
    }

    // ------------------------------------------------------------------ layout helpers

    private GridPane buildHeader() {
        Label title = new Label("TCP Chat Server");
        title.getStyleClass().add("app-title");
        endpointLabel.getStyleClass().add("subtitle");
        VBox titleBox = new VBox(2, title, endpointLabel);

        statusLabel.getStyleClass().add("status-label");
        HBox statusBox = new HBox(8, statusDot, statusLabel);
        statusBox.setAlignment(Pos.CENTER);

        countLabel.getStyleClass().add("count-badge");

        GridPane header = new GridPane();
        header.getStyleClass().add("server-header");
        header.setHgap(20);
        ColumnConstraints grow = new ColumnConstraints();
        grow.setHgrow(Priority.ALWAYS);
        header.getColumnConstraints().addAll(grow, new ColumnConstraints(), new ColumnConstraints());
        header.add(titleBox, 0, 0);
        header.add(statusBox, 1, 0);
        header.add(countLabel, 2, 0);
        GridPane.setValignment(statusBox, javafx.geometry.VPos.CENTER);
        GridPane.setValignment(countLabel, javafx.geometry.VPos.CENTER);
        return header;
    }

    private GridPane buildFooter() {
        toggleButton.getStyleClass().add("primary-button");
        clearButton.getStyleClass().add("secondary-button");
        clearButton.setOnAction(e -> logLines.clear());

        Label hint = new Label("Clients connect to the address above. Users get random colours in the list.");
        hint.getStyleClass().add("hint");

        GridPane footer = new GridPane();
        footer.getStyleClass().add("server-footer");
        footer.setHgap(10);
        ColumnConstraints grow = new ColumnConstraints();
        grow.setHgrow(Priority.ALWAYS);
        footer.getColumnConstraints().addAll(new ColumnConstraints(), new ColumnConstraints(), grow);
        footer.add(toggleButton, 0, 0);
        footer.add(clearButton, 1, 0);
        footer.add(hint, 2, 0);
        GridPane.setHalignment(hint, javafx.geometry.HPos.RIGHT);
        return footer;
    }

    private Label sectionTitle(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("section-title");
        GridPane.setMargin(label, new Insets(14, 16, 6, 16));
        return label;
    }

    // ------------------------------------------------------------------ lists

    private void configureLists() {
        userList.getStyleClass().add("user-list");
        userList.setPlaceholder(new Label("No clients connected"));
        userList.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle(null);
                } else {
                    setText(item);
                    // Random (but stable per user) background colour to tell users apart.
                    setStyle("-fx-background-color: " + colorFor(item) + ";");
                }
            }
        });

        logList.getStyleClass().add("log-list");
        logList.setCellFactory(lv -> new ListCell<>() {
            {
                setWrapText(true);
                setPrefWidth(0);
            }

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle(null);
                } else {
                    setText(item);
                    setStyle("-fx-text-fill: " + logColor(item) + ";");
                }
            }
        });
    }

    private static String logColor(String line) {
        if (line.contains("ERROR")) {
            return "#dc2626";
        }
        if (line.contains("Server Started")) {
            return "#16a34a";
        }
        if (line.contains("Welcome")) {
            return "#2563eb";
        }
        if (line.contains("Goodbye") || line.contains("Server Stopped")) {
            return "#d97706";
        }
        return "#334155";
    }

    private String colorFor(String name) {
        return userColors.computeIfAbsent(name, n -> {
            Color c = Color.hsb(random.nextDouble() * 360, 0.28 + random.nextDouble() * 0.27, 0.97);
            return String.format("#%02X%02X%02X",
                    Math.round(c.getRed() * 255), Math.round(c.getGreen() * 255), Math.round(c.getBlue() * 255));
        });
    }
}
