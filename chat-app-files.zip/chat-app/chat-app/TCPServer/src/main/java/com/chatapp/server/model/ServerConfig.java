package com.chatapp.server.model;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Network configuration of the server, loaded at runtime so that deployment changes
 * never require recompilation.
 *
 * <p>Lookup order:
 * <ol>
 *   <li>file given by {@code -Dserver.config=/path/server.properties}</li>
 *   <li>{@code server.properties} in the working directory</li>
 *   <li>the default {@code server.properties} bundled inside the JAR</li>
 *   <li>built-in defaults (0.0.0.0:3000)</li>
 * </ol>
 *
 * @param host   address the server binds to ("0.0.0.0" = all interfaces)
 * @param port   TCP port (0 = pick a free port, used by tests)
 * @param source human-readable description of where the values came from
 */
public record ServerConfig(String host, int port, String source) {

    public static final String DEFAULT_HOST = "0.0.0.0";
    public static final int DEFAULT_PORT = 3000;

    public ServerConfig {
        if (host == null || host.isBlank()) {
            throw new IllegalArgumentException("server.host must not be empty");
        }
        if (port < 0 || port > 65535) {
            throw new IllegalArgumentException("server.port must be between 0 and 65535 (was " + port + ")");
        }
    }

    public String endpoint() {
        return host + ":" + port;
    }

    public static ServerConfig load() {
        Properties props = new Properties();
        String source = "built-in defaults";

        String override = System.getProperty("server.config");
        Path external = Path.of(override != null ? override : "server.properties");

        try {
            if (Files.isRegularFile(external)) {
                try (Reader reader = Files.newBufferedReader(external, StandardCharsets.UTF_8)) {
                    props.load(reader);
                }
                source = external.toAbsolutePath().toString();
            } else {
                try (InputStream in = ServerConfig.class.getResourceAsStream("/server.properties")) {
                    if (in != null) {
                        props.load(in);
                        source = "classpath:/server.properties";
                    }
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read server configuration", e);
        }

        String host = props.getProperty("server.host", DEFAULT_HOST).trim();
        int port = parsePort(props.getProperty("server.port", String.valueOf(DEFAULT_PORT)));
        return new ServerConfig(host, port, source);
    }

    private static int parsePort(String raw) {
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("server.port is not a number: '" + raw + "'");
        }
    }
}
