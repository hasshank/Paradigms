package com.chatapp.server.controller;

import com.chatapp.server.model.ChatServer;
import com.chatapp.server.model.ServerConfig;
import com.chatapp.server.model.ServerListener;
import com.chatapp.server.view.ServerView;
import javafx.application.Platform;

import java.io.IOException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Glue between the model ({@link ChatServer}) and the view ({@link ServerView}).
 * It is the only class that knows both; the model calls back through {@link ServerListener}
 * on server threads, so every UI update is marshalled to the JavaFX thread here.
 */
public class ServerController implements ServerListener {

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final ServerConfig config;
    private final ServerView view;
    private ChatServer server;

    public ServerController(ServerConfig config, ServerView view) {
        this.config = config;
        this.view = view;
        view.onToggle(this::toggle);
    }

    public void start() {
        view.appendLog(stamp("Configuration loaded from " + config.source()));
        server = new ChatServer(config, this);
        try {
            server.start();
            view.setRunning(true, config.endpoint());
        } catch (IOException e) {
            view.setRunning(false, "");
            view.appendLog(stamp("ERROR: cannot start server on " + config.endpoint() + ": " + e.getMessage()));
        }
    }

    public void stop() {
        if (server != null && server.isRunning()) {
            server.stop();
        }
        view.clearUsers();
        view.setRunning(false, "");
    }

    public void shutdown() {
        if (server != null) {
            server.stop();
        }
    }

    private void toggle() {
        if (server != null && server.isRunning()) {
            stop();
        } else {
            start();
        }
    }

    // ------------------------------------------------------------------ ServerListener (server threads)

    @Override
    public void onLog(String message) {
        String line = stamp(message);
        Platform.runLater(() -> view.appendLog(line));
    }

    @Override
    public void onUserJoined(String displayName) {
        Platform.runLater(() -> view.addUser(displayName));
    }

    @Override
    public void onUserLeft(String displayName) {
        Platform.runLater(() -> view.removeUser(displayName));
    }

    private static String stamp(String message) {
        return "[" + LocalTime.now().format(TIME) + "] " + message;
    }
}
