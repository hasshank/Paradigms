package com.chatapp.server.model;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * The chat server model: accepts TCP connections and distributes messages.
 *
 * <p>Concurrency model: one virtual thread runs the accept loop and one virtual thread is
 * spawned per connected client ({@link ClientHandler}). Virtual threads are cheap, so
 * blocking I/O ({@code readLine}) is the simplest correct design here.
 *
 * <p>This class has no dependency on JavaFX: it can be driven from a GUI, a console or a test.
 */
public class ChatServer {

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final ServerConfig config;
    private final ServerListener listener;

    /** Lower-cased usernames already taken (includes names that are mid-handshake). */
    private final Map<String, ClientHandler> reservedNames = new ConcurrentHashMap<>();
    /** Every open connection, even before the handshake completed. */
    private final Set<ClientHandler> connections = ConcurrentHashMap.newKeySet();
    /** Connections that completed the handshake and receive broadcasts. */
    private final Set<ClientHandler> active = new CopyOnWriteArraySet<>();
    private final AtomicInteger viewerCounter = new AtomicInteger();

    private volatile ServerSocket serverSocket;
    private volatile ExecutorService executor;
    private volatile boolean running;

    public ChatServer(ServerConfig config, ServerListener listener) {
        this.config = config;
        this.listener = listener;
    }

    // ------------------------------------------------------------------ lifecycle

    public synchronized void start() throws IOException {
        if (running) {
            return;
        }
        ServerSocket ss = new ServerSocket();
        try {
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(config.host(), config.port()));
        } catch (IOException e) {
            ss.close();
            throw e;
        }
        serverSocket = ss;
        executor = Executors.newVirtualThreadPerTaskExecutor();
        running = true;
        listener.onLog("Server Started on " + ss.getInetAddress().getHostAddress() + ":" + ss.getLocalPort());
        executor.execute(this::acceptLoop);
    }

    public synchronized void stop() {
        if (!running) {
            return;
        }
        running = false;
        try {
            serverSocket.close();
        } catch (IOException ignored) {
            // closing anyway
        }
        for (ClientHandler handler : connections) {
            handler.send(Protocol.frame(Protocol.SYS, "Server is shutting down"));
            handler.close();
        }
        executor.shutdownNow();
        listener.onLog("Server Stopped");
    }

    public boolean isRunning() {
        return running;
    }

    /** The actual bound port (useful when configured with port 0). */
    public int getLocalPort() {
        ServerSocket ss = serverSocket;
        return ss == null ? -1 : ss.getLocalPort();
    }

    /** Usernames of the active, non read-only clients, sorted alphabetically. */
    public List<String> getConnectedUsers() {
        return active.stream()
                .filter(h -> !h.isReadOnly())
                .map(ClientHandler::displayName)
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .toList();
    }

    // ------------------------------------------------------------------ accept loop

    private void acceptLoop() {
        ServerSocket ss = serverSocket;
        while (running) {
            try {
                listener.onLog("Waiting for Client...");
                Socket socket = ss.accept();
                socket.setTcpNoDelay(true);
                ClientHandler handler = new ClientHandler(this, socket);
                connections.add(handler);
                listener.onLog("Connection accepted from " + handler.remoteAddress());
                try {
                    executor.execute(handler);
                } catch (RejectedExecutionException e) {
                    handler.close();
                }
            } catch (IOException e) {
                if (running) {
                    listener.onLog("ERROR: accept failed: " + e.getMessage());
                    pause();
                }
            }
        }
    }

    private static void pause() {
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // ------------------------------------------------------------------ used by ClientHandler

    void log(String message) {
        listener.onLog(message);
    }

    String nextViewerName() {
        return "viewer-" + viewerCounter.incrementAndGet() + " (read-only)";
    }

    /** Atomically claims a username (case-insensitive). */
    boolean reserveName(ClientHandler handler) {
        return reservedNames.putIfAbsent(handler.displayName().toLowerCase(Locale.ROOT), handler) == null;
    }

    /** Called once the handshake succeeded and "OK" was sent: from now on the client receives broadcasts. */
    void activate(ClientHandler handler) {
        active.add(handler);
        listener.onUserJoined(handler.displayName());
        listener.onLog("Welcome " + handler.displayName());
        if (handler.isReadOnly()) {
            handler.send(Protocol.frame(Protocol.SYS,
                    "Welcome! You are in READ-ONLY MODE: you can read messages but not send any."));
        } else {
            handler.send(Protocol.frame(Protocol.SYS, "Welcome " + handler.displayName() + "! "
                    + "Type allUsers to list active users, or end / bye to leave."));
            broadcast(Protocol.frame(Protocol.SYS, handler.displayName() + " joined the chat"), handler);
        }
    }

    /** Called exactly once per handler when its connection is closed. */
    void release(ClientHandler handler) {
        connections.remove(handler);
        if (handler.isReserved()) {
            reservedNames.remove(handler.displayName().toLowerCase(Locale.ROOT), handler);
        }
        if (active.remove(handler)) {
            listener.onUserLeft(handler.displayName());
            listener.onLog("Goodbye " + handler.displayName());
            if (running && !handler.isReadOnly()) {
                broadcast(Protocol.frame(Protocol.SYS, handler.displayName() + " left the chat"), null);
            }
        }
    }

    /**
     * Formats a chat message with the sender's username and the current time, then sends it
     * to every active connection (including the sender, whose client shows the server-stamped copy).
     *
     * @param escapedText the text exactly as received (still escaped, so it stays on one line)
     */
    void broadcastChat(ClientHandler sender, String escapedText) {
        String time = LocalTime.now().format(TIME);
        listener.onLog(sender.displayName() + ": " + Protocol.unescape(escapedText).replace('\n', ' '));
        broadcast(Protocol.frame(Protocol.MSG, time, sender.displayName(), escapedText), null);
    }

    void broadcast(String frame, ClientHandler except) {
        for (ClientHandler handler : active) {
            if (handler != except) {
                handler.send(frame);
            }
        }
    }
}
