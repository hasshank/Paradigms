import com.chatapp.server.ServerApp;

/**
 * Entry point of the chat server: {@code java TCPServer}.
 *
 * <p>This class deliberately does NOT extend {@code javafx.application.Application}, so the
 * fat JAR can be started with {@code java -jar} without a JavaFX module path.
 * Network settings (bind address and port) come from {@code server.properties}.
 */
public class TCPServer {

    public static void main(String[] args) {
        ServerApp.launchApp(args);
    }
}
