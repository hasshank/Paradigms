package com.chatapp.server.model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.function.BooleanSupplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Headless tests of the server model: no JavaFX involved, raw sockets play the clients.
 * They double as proof that the model is independent of the view.
 */
class ChatServerTest {

    private ChatServer server;
    private final List<String> logs = Collections.synchronizedList(new java.util.ArrayList<>());
    private final List<String> joined = Collections.synchronizedList(new java.util.ArrayList<>());
    private final List<String> left = Collections.synchronizedList(new java.util.ArrayList<>());
    private final List<Peer> peers = new java.util.ArrayList<>();

    @BeforeEach
    void startServer() throws IOException {
        server = new ChatServer(new ServerConfig("127.0.0.1", 0, "test"), new ServerListener() {
            @Override
            public void onLog(String message) {
                logs.add(message);
            }

            @Override
            public void onUserJoined(String displayName) {
                joined.add(displayName);
            }

            @Override
            public void onUserLeft(String displayName) {
                left.add(displayName);
            }
        });
        server.start();
    }

    @AfterEach
    void stopServer() {
        for (Peer p : peers) {
            p.close();
        }
        server.stop();
    }

    @Test
    void logsStartupWaitingAndWelcome() throws Exception {
        Peer alice = connect();
        assertEquals("OK|USER", alice.join("alice"));

        await(() -> logs.stream().anyMatch(l -> l.startsWith("Server Started")));
        await(() -> logs.stream().anyMatch(l -> l.startsWith("Waiting for Client")));
        await(() -> logs.contains("Welcome alice"));
        assertEquals(List.of("alice"), joined);
    }

    @Test
    void messageIsStampedAndDeliveredToEveryone() throws Exception {
        Peer alice = connect();
        Peer bob = connect();
        alice.join("alice");
        bob.join("bob");
        alice.readUntil("SYS|bob joined the chat");

        alice.send("MSG|hello world");

        assertTrue(bob.readUntil("MSG|").matches("MSG\\|\\d\\d:\\d\\d:\\d\\d\\|alice\\|hello world"));
        assertTrue(alice.readUntil("MSG|").endsWith("|alice|hello world"), "sender gets the stamped copy too");
    }

    @Test
    void multilineTextStaysOnOneLine() throws Exception {
        Peer alice = connect();
        Peer bob = connect();
        alice.join("alice");
        bob.join("bob");

        alice.send("MSG|" + Protocol.escape("line1\nline2"));

        String received = bob.readUntil("MSG|");
        String text = received.split("\\|", 4)[3];
        assertEquals("line1\nline2", Protocol.unescape(text));
    }

    @Test
    void duplicateUsernameIsRejectedCaseInsensitively() throws Exception {
        connect().join("alice");
        String reply = connect().join("ALICE");
        assertTrue(reply.startsWith("ERR|"), reply);
        assertEquals(List.of("alice"), server.getConnectedUsers());
    }

    @Test
    void invalidUsernameIsRejected() throws Exception {
        assertTrue(connect().join("bad|name").startsWith("ERR|"));
        assertTrue(connect().join("x".repeat(21)).startsWith("ERR|"));
    }

    @Test
    void blankUsernameMeansReadOnlyAndCannotSend() throws Exception {
        Peer alice = connect();
        Peer viewer = connect();
        alice.join("alice");
        assertEquals("OK|READONLY", viewer.join(""));
        viewer.readUntil("SYS|Welcome");

        viewer.send("MSG|can I talk?");
        assertTrue(viewer.readUntil("SYS|READ-ONLY").contains("cannot send"));

        // The viewer still receives what others say, and its text never reached alice.
        alice.send("MSG|ping");
        assertTrue(alice.readUntil("MSG|").endsWith("|alice|ping"));
        assertTrue(viewer.readUntil("MSG|").endsWith("|alice|ping"));
    }

    @Test
    void allUsersListsOnlyNamedUsersAndOnlyToTheAsker() throws Exception {
        Peer alice = connect();
        Peer bob = connect();
        Peer viewer = connect();
        alice.join("alice");
        bob.join("bob");
        viewer.join("");

        alice.send("CMD|allUsers");
        assertEquals("USERS|alice,bob", alice.readUntil("USERS|"));

        bob.send("MSG|marker");
        // bob's next MSG line is his own message: he never received alice's USERS reply.
        assertTrue(bob.readUntil("MSG|").endsWith("|bob|marker"));
    }

    @Test
    void byeClosesConnectionAndNotifiesOthers() throws Exception {
        Peer alice = connect();
        Peer bob = connect();
        alice.join("alice");
        bob.join("bob");

        bob.send("BYE");

        alice.readUntil("SYS|bob left the chat");
        await(() -> server.getConnectedUsers().equals(List.of("alice")));
        assertTrue(left.contains("bob"));
        assertNotNull(bob.readUntilEof());
    }

    @Test
    void abruptDisconnectIsDetected() throws Exception {
        Peer alice = connect();
        Peer bob = connect();
        alice.join("alice");
        bob.join("bob");

        bob.socket.close();

        alice.readUntil("SYS|bob left the chat");
        assertFalse(server.getConnectedUsers().contains("bob"));
    }

    @Test
    void usernameCanBeReusedAfterLeaving() throws Exception {
        Peer first = connect();
        first.join("alice");
        first.send("BYE");
        await(() -> server.getConnectedUsers().isEmpty());

        assertEquals("OK|USER", connect().join("alice"));
    }

    @Test
    void manyClientsConnectConcurrently() throws Exception {
        int n = 50;
        List<Peer> list = new java.util.ArrayList<>();
        for (int i = 0; i < n; i++) {
            Peer p = connect();
            assertEquals("OK|USER", p.join("user" + i));
            list.add(p);
        }
        assertEquals(n, server.getConnectedUsers().size());

        list.get(0).send("MSG|broadcast");
        for (Peer p : list) {
            assertTrue(p.readUntil("MSG|").endsWith("|user0|broadcast"));
        }
    }

    // ------------------------------------------------------------------ helpers

    private Peer connect() throws IOException {
        Peer p = new Peer(server.getLocalPort());
        peers.add(p);
        return p;
    }

    private static void await(BooleanSupplier condition) throws InterruptedException {
        long deadline = System.nanoTime() + 3_000_000_000L;
        while (!condition.getAsBoolean()) {
            if (System.nanoTime() > deadline) {
                throw new AssertionError("Condition not met within 3 seconds");
            }
            Thread.sleep(20);
        }
    }

    /** A bare-bones TCP client used to talk to the server. */
    private static final class Peer implements AutoCloseable {
        final Socket socket;
        final BufferedReader in;
        final BufferedWriter out;

        Peer(int port) throws IOException {
            socket = new Socket("127.0.0.1", port);
            socket.setSoTimeout(3000);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
        }

        void send(String line) throws IOException {
            out.write(line);
            out.write('\n');
            out.flush();
        }

        String join(String name) throws IOException {
            send("JOIN|" + name);
            return in.readLine();
        }

        /** Reads lines until one starts with the prefix; fails on timeout or EOF. */
        String readUntil(String prefix) throws IOException {
            String line;
            while ((line = in.readLine()) != null) {
                if (line.startsWith(prefix)) {
                    return line;
                }
            }
            throw new AssertionError("Connection closed while waiting for '" + prefix + "'");
        }

        /** Drains until the server closes the connection. */
        String readUntilEof() throws IOException {
            while (in.readLine() != null) {
                // drain
            }
            return "eof";
        }

        @Override
        public void close() {
            try {
                socket.close();
            } catch (IOException ignored) {
                // test cleanup
            }
        }
    }
}
