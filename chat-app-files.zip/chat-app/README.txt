TCPServer.jar / TCPClient.jar contain the application only. JavaFX is platform-specific, so download the
JavaFX SDK (21+) for your OS from https://gluonhq.com/products/javafx/ and unzip it. Then:

  java --module-path /path/to/javafx-sdk/lib --add-modules javafx.controls -jar TCPServer.jar
  java --module-path /path/to/javafx-sdk/lib --add-modules javafx.controls -jar TCPClient.jar localhost 3000

(Windows: use backslashes, e.g. C:\javafx-sdk-21\lib). Needs JDK 21+.
Optional: put server.properties / client.properties next to the JAR to change host and port.
