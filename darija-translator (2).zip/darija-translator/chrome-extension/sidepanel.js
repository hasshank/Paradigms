// Side panel logic: auto-translate pasted selection, call REST endpoint, TTS, dictation.

const DEFAULTS = {
  url: "http://localhost:8080/api/translate",
  user: "admin",
  pass: "changeme",
  speechLang: "en-US",
};

const $ = (id) => document.getElementById(id);
const els = {
  source: $("source"), result: $("result"), status: $("status"), script: $("script"),
  url: $("url"), user: $("user"), pass: $("pass"), speechLang: $("speechLang"),
};

let settings = { ...DEFAULTS };
let lastSeenAt = 0;

function setStatus(msg, isError = false) {
  els.status.textContent = msg;
  els.status.classList.toggle("error", isError);
}

async function loadSettings() {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULTS));
  settings = { ...DEFAULTS, ...stored };
  els.url.value = settings.url;
  els.user.value = settings.user;
  els.pass.value = settings.pass;
  els.speechLang.value = settings.speechLang;
}

async function saveSettings() {
  settings = {
    url: els.url.value.trim() || DEFAULTS.url,
    user: els.user.value,
    pass: els.pass.value,
    speechLang: els.speechLang.value,
  };
  await chrome.storage.local.set(settings);
  setStatus("Settings saved");
}

// utf-8 safe Basic header
function basicAuth(user, pass) {
  const bytes = new TextEncoder().encode(`${user}:${pass}`);
  let bin = "";
  bytes.forEach((b) => (bin += String.fromCharCode(b)));
  return "Basic " + btoa(bin);
}

async function translate() {
  const text = els.source.value.trim();
  if (!text) { setStatus("Nothing to translate", true); return null; }
  setStatus("Translating…");
  els.result.textContent = "";
  try {
    const res = await fetch(settings.url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": basicAuth(settings.user, settings.pass),
      },
      body: JSON.stringify({ text, script: els.script.value }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    els.result.textContent = data.translation;
    setStatus(`Done (${data.model})`);
    return data.translation;
  } catch (e) {
    setStatus(e.message, true);
    return null;
  }
}

// ---------- Text-to-speech (read aloud) ----------
function speak(text) {
  if (!text) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  // Prefer a Moroccan voice, then any Arabic voice.
  const voices = speechSynthesis.getVoices();
  const voice = voices.find((v) => v.lang === "ar-MA") || voices.find((v) => v.lang.startsWith("ar"));
  if (voice) { u.voice = voice; u.lang = voice.lang; } else { u.lang = "ar-MA"; }
  speechSynthesis.speak(u);
}

// ---------- Speech-to-text (dictation) ----------
const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognizer = null;

function listen(onFinal) {
  if (!Recognition) { setStatus("Speech recognition not supported in this browser", true); return; }
  if (recognizer) { recognizer.stop(); return; }
  recognizer = new Recognition();
  recognizer.lang = settings.speechLang;
  recognizer.interimResults = true;
  $("mic").classList.add("recording");
  setStatus("Listening…");
  let finalText = "";
  recognizer.onresult = (ev) => {
    let interim = "";
    for (const r of ev.results) {
      if (r.isFinal) finalText += r[0].transcript; else interim += r[0].transcript;
    }
    els.source.value = (finalText + interim).trim();
  };
  recognizer.onerror = (ev) => {
    const hint = ev.error === "not-allowed"
      ? "Microphone blocked. Open the extension's site settings (chrome://settings/content/microphone) and allow it."
      : ev.error;
    setStatus(hint, true);
  };
  recognizer.onend = () => {
    recognizer = null;
    $("mic").classList.remove("recording");
    if (finalText.trim() && onFinal) onFinal(); else if (!els.status.classList.contains("error")) setStatus("");
  };
  recognizer.start();
}

// ---------- Wiring ----------
$("translate").addEventListener("click", translate);
$("save").addEventListener("click", saveSettings);
$("copy").addEventListener("click", () => navigator.clipboard.writeText(els.result.textContent));
$("speak").addEventListener("click", () => speak(els.result.textContent));
$("stop").addEventListener("click", () => speechSynthesis.cancel());
$("mic").addEventListener("click", () => listen(null));
$("voice2voice").addEventListener("click", () =>
  listen(async () => { const t = await translate(); if (t) speak(t); }));
els.source.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) translate();
});

// Pick up text sent from the context menu / shortcut.
async function consumePending() {
  const { pendingText, pendingAt } = await chrome.storage.session.get(["pendingText", "pendingAt"]);
  if (pendingText && pendingAt && pendingAt > lastSeenAt) {
    lastSeenAt = pendingAt;
    els.source.value = pendingText;
    translate();
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && changes.pendingAt) consumePending();
});

(async () => {
  await loadSettings();
  await consumePending();
})();
