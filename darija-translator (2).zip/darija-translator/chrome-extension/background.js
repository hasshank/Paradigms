// Service worker: context menu + keyboard shortcut -> copy selection -> open side panel.

const MENU_ID = "translate-darija";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: "Translate to Darija: \"%s\"",
    contexts: ["selection"],
  });
  // Clicking the toolbar icon opens the side panel too.
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);
});

async function sendSelection(text, tab) {
  // session storage lets the side panel pick up the text even if it opens after this write.
  await chrome.storage.session.set({ pendingText: text, pendingAt: Date.now() });
  if (tab && tab.windowId !== undefined) {
    await chrome.sidePanel.open({ windowId: tab.windowId });
  }
}

// Right-click menu: info.selectionText is the selected text (automatic copy/paste).
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === MENU_ID && info.selectionText) {
    // Must call sidePanel.open synchronously within the user gesture.
    chrome.sidePanel.open({ windowId: tab.windowId }).catch(console.error);
    chrome.storage.session.set({ pendingText: info.selectionText, pendingAt: Date.now() });
  }
});

// Alt+D: read the current selection from the page and translate it.
chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== "translate-selection" || !tab) return;
  // Open first to keep the user-gesture, then fetch the selection.
  chrome.sidePanel.open({ windowId: tab.windowId }).catch(console.error);
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => window.getSelection().toString(),
    });
    const text = (res && res.result || "").trim();
    if (text) {
      await chrome.storage.session.set({ pendingText: text, pendingAt: Date.now() });
    }
  } catch (e) {
    console.warn("Cannot read selection on this page:", e);
  }
});
