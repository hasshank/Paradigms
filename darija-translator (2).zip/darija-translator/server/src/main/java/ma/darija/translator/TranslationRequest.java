package ma.darija.translator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** Request body of POST /api/translate. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TranslationRequest {

    /** Text to translate (required). */
    public String text;

    /** Optional source language hint, e.g. "English" or "French". Auto-detected when absent. */
    public String source;

    /** "arabic" (default, Arabic script) or "latin" (Arabizi, e.g. "kifach halek"). */
    public String script;

    public TranslationRequest() {}

    public TranslationRequest(String text, String source, String script) {
        this.text = text;
        this.source = source;
        this.script = script;
    }
}
