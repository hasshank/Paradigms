package ma.darija.translator;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Client for a Qwen model served through an OpenAI-compatible /chat/completions API.
 *
 * Works unchanged with:
 *   - Ollama (local / Google Colab):  LLM_BASE_URL=http://localhost:11434/v1  LLM_MODEL=qwen2.5:7b-instruct
 *   - Alibaba Cloud DashScope:        LLM_BASE_URL=https://dashscope-intl.aliyuncs.com/compatible-mode/v1
 *                                     LLM_MODEL=qwen-plus  LLM_API_KEY=sk-...
 *   - vLLM / LM Studio / any other OpenAI-compatible server hosting Qwen.
 */
public class LlmClient {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private final String baseUrl;
    private final String model;
    private final String apiKey;

    public LlmClient() {
        this(Config.get("LLM_BASE_URL", "http://localhost:11434/v1"),
             Config.get("LLM_MODEL", "qwen2.5:7b-instruct"),
             Config.get("LLM_API_KEY", ""));
    }

    public LlmClient(String baseUrl, String model, String apiKey) {
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        this.model = model;
        this.apiKey = apiKey;
    }

    public String getModel() {
        return model;
    }

    /** Builds the system prompt that steers Qwen towards Moroccan Darija. */
    static String systemPrompt(String source, String script) {
        boolean latin = "latin".equalsIgnoreCase(script);
        StringBuilder sb = new StringBuilder();
        sb.append("You are a professional translator into Moroccan Arabic (Darija). ");
        sb.append(source == null || source.isBlank()
                ? "Detect the source language automatically. "
                : "The source language is " + source + ". ");
        sb.append("Translate the user's text into natural, everyday Moroccan Darija, NOT Modern Standard Arabic. ");
        if (latin) {
            sb.append("Write the result in Latin letters with numerals for Arabic sounds (Arabizi). ");
            sb.append("Examples: 'How are you?' -> 'kifach halek?'; 'I want water' -> 'bghit lma'. ");
        } else {
            sb.append("Write the result in Arabic script. ");
            sb.append("Examples: 'How are you?' -> 'كيف داير؟'; 'I want water' -> 'بغيت الماء'; ");
            sb.append("'Where is the station?' -> 'فين كاينة المحطة؟'. ");
        }
        sb.append("Return ONLY the translation, with no explanations, notes, quotes or markdown.");
        return sb.toString();
    }

    public String translate(String text, String source, String script) throws IOException, InterruptedException {
        Map<String, Object> body = Map.of(
                "model", model,
                "temperature", 0.2,
                "stream", false,
                "messages", List.of(
                        Map.of("role", "system", "content", systemPrompt(source, script)),
                        Map.of("role", "user", "content", text)));

        HttpRequest.Builder rb = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofMinutes(3))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(MAPPER.writeValueAsString(body)));
        if (apiKey != null && !apiKey.isBlank()) {
            rb.header("Authorization", "Bearer " + apiKey);
        }

        HttpResponse<String> response;
        try {
            response = http.send(rb.build(), HttpResponse.BodyHandlers.ofString());
        } catch (java.net.ConnectException e) {
            throw new IOException("Cannot reach the LLM server at " + baseUrl + " (is Ollama running?)", e);
        }
        if (response.statusCode() / 100 != 2) {
            throw new IOException("LLM server returned HTTP " + response.statusCode() + ": " + response.body());
        }
        return extractText(response.body());
    }

    /** Pulls choices[0].message.content out of a chat-completions response and strips any reasoning block. */
    static String extractText(String json) throws IOException {
        JsonNode content = MAPPER.readTree(json).path("choices").path(0).path("message").path("content");
        if (content.isMissingNode() || content.isNull()) {
            throw new IOException("The LLM returned no translation");
        }
        String text = content.asText("")
                .replaceAll("(?s)<think>.*?</think>", "")   // Qwen3 reasoning output, if any
                .trim();
        if (text.isEmpty()) {
            throw new IOException("The LLM returned an empty translation");
        }
        return text;
    }
}
