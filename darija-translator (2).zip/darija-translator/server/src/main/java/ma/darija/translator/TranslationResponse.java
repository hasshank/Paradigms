package ma.darija.translator;

/** Response body of /api/translate. */
public class TranslationResponse {

    public String original;
    public String translation;
    public String model;

    public TranslationResponse() {}

    public TranslationResponse(String original, String translation, String model) {
        this.original = original;
        this.translation = translation;
        this.model = model;
    }
}
