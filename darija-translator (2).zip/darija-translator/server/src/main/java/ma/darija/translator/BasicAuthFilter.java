package ma.darija.translator;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Map;

import jakarta.annotation.Priority;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;

/**
 * HTTP Basic authentication for the endpoint.
 *
 * Credentials come from AUTH_USER / AUTH_PASSWORD. CORS preflight (OPTIONS) and the
 * /translate/health probe are public. Use HTTPS (reverse proxy) outside of localhost,
 * because Basic credentials are only Base64-encoded.
 */
@Provider
@Priority(Priorities.AUTHENTICATION)
public class BasicAuthFilter implements ContainerRequestFilter {

    private final String user = Config.get("AUTH_USER", "admin");
    private final String password = Config.get("AUTH_PASSWORD", "changeme");

    @Override
    public void filter(ContainerRequestContext ctx) {
        if ("OPTIONS".equalsIgnoreCase(ctx.getMethod())) {
            return;
        }
        String path = ctx.getUriInfo().getPath();
        if (path.endsWith("/health")) {
            return;
        }
        if (!isAuthorized(ctx.getHeaderString(HttpHeaders.AUTHORIZATION))) {
            ctx.abortWith(Response.status(Response.Status.UNAUTHORIZED)
                    .header(HttpHeaders.WWW_AUTHENTICATE, "Basic realm=\"Darija Translator\", charset=\"UTF-8\"")
                    .type(MediaType.APPLICATION_JSON)
                    .entity(Map.of("error", "Authentication required"))
                    .build());
        }
    }

    boolean isAuthorized(String header) {
        if (header == null || !header.regionMatches(true, 0, "Basic ", 0, 6)) {
            return false;
        }
        String decoded;
        try {
            decoded = new String(Base64.getDecoder().decode(header.substring(6).trim()), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return false;
        }
        int idx = decoded.indexOf(':');
        if (idx < 0) {
            return false;
        }
        boolean userOk = constantTimeEquals(decoded.substring(0, idx), user);
        boolean passOk = constantTimeEquals(decoded.substring(idx + 1), password);
        return userOk && passOk;
    }

    private static boolean constantTimeEquals(String a, String b) {
        return MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }
}
