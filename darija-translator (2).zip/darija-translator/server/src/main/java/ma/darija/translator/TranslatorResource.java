package ma.darija.translator;

import java.io.IOException;
import java.util.Map;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * RESTful endpoint /api/translate.
 *
 *   POST /api/translate   {"text": "...", "source": "English", "script": "arabic"}
 *   GET  /api/translate?text=...&source=...&script=...
 *   GET  /api/translate/health   (public)
 */
@Path("/api/translate")
@Produces(MediaType.APPLICATION_JSON + ";charset=UTF-8")
public class TranslatorResource {

    static final int MAX_CHARS = 5000;

    private static final LlmClient LLM = new LlmClient();

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response translate(TranslationRequest req) {
        if (req == null) {
            return error(Response.Status.BAD_REQUEST, "Request body is required");
        }
        return doTranslate(req.text, req.source, req.script);
    }

    @GET
    public Response translateGet(@QueryParam("text") String text,
                                 @QueryParam("source") String source,
                                 @QueryParam("script") String script) {
        return doTranslate(text, source, script);
    }

    @GET
    @Path("/health")
    public Map<String, String> health() {
        return Map.of("status", "UP", "model", LLM.getModel());
    }

    /** Business method: validates the input, calls the LLM, wraps the result. */
    public Response doTranslate(String text, String source, String script) {
        if (text == null || text.isBlank()) {
            return error(Response.Status.BAD_REQUEST, "Field 'text' must not be empty");
        }
        if (text.length() > MAX_CHARS) {
            return error(Response.Status.BAD_REQUEST, "Text too long (max " + MAX_CHARS + " characters)");
        }
        try {
            String translation = LLM.translate(text.trim(), source, script);
            return Response.ok(new TranslationResponse(text, translation, LLM.getModel())).build();
        } catch (IOException e) {
            return error(Response.Status.BAD_GATEWAY, e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return error(Response.Status.SERVICE_UNAVAILABLE, "Interrupted");
        }
    }

    private static Response error(Response.Status status, String message) {
        return Response.status(status).entity(Map.of("error", message)).build();
    }
}
