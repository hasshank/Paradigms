package ma.darija.translator;

import java.io.IOException;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.ext.Provider;

/** Adds CORS headers so browser clients (extension, web pages) can call the API. */
@Provider
public class CorsFilter implements ContainerResponseFilter {

    @Override
    public void filter(ContainerRequestContext req, ContainerResponseContext res) throws IOException {
        res.getHeaders().putSingle("Access-Control-Allow-Origin", Config.get("CORS_ORIGIN", "*"));
        res.getHeaders().putSingle("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        res.getHeaders().putSingle("Access-Control-Allow-Headers", "Authorization, Content-Type");
        res.getHeaders().putSingle("Access-Control-Max-Age", "86400");
    }
}
