package ma.darija.translator;

/** Tiny configuration helper: environment variable first, then system property, then default. */
public final class Config {

    private Config() {}

    public static String get(String key, String defaultValue) {
        String v = System.getenv(key);
        if (v == null || v.isBlank()) {
            v = System.getProperty(key);
        }
        return (v == null || v.isBlank()) ? defaultValue : v;
    }
}
