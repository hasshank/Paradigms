package ma.darija.translator;

import java.net.URI;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;

/**
 * Entry point: starts an embedded Grizzly container hosting the Jakarta REST application.
 *
 * Configuration (environment variables):
 *   LLM_BASE_URL     (optional) OpenAI-compatible endpoint, default http://localhost:11434/v1 (Ollama)
 *   LLM_MODEL        (optional) default qwen2.5:7b-instruct
 *   LLM_API_KEY      (optional) only for hosted APIs such as Alibaba DashScope
 *   AUTH_USER        (optional) default "admin"
 *   AUTH_PASSWORD    (optional) default "changeme"
 *   PORT             (optional) default 8080
 */
public class Main {

    public static void main(String[] args) throws Exception {
        String port = Config.get("PORT", "8080");
        // Mounted at the root; TranslatorResource's @Path carries the /api/translate prefix.
        URI baseUri = URI.create("http://0.0.0.0:" + port + "/");

        HttpServer server = GrizzlyHttpServerFactory.createHttpServer(baseUri, new TranslatorApplication());
        Runtime.getRuntime().addShutdownHook(new Thread(server::shutdownNow));

        System.out.println("Darija Translator running on http://localhost:" + port + "/api/translate");
        System.out.println("LLM backend: " + Config.get("LLM_BASE_URL", "http://localhost:11434/v1")
                + " model=" + Config.get("LLM_MODEL", "qwen2.5:7b-instruct"));
        System.out.println("Press Ctrl+C to stop.");
        Thread.currentThread().join();
    }
}
