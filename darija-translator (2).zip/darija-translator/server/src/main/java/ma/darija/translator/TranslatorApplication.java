package ma.darija.translator;

import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.server.ResourceConfig;

/** Jakarta REST application: registers resources, filters and the JSON provider. Mounted at / by Main; resources carry the /api prefix. */
public class TranslatorApplication extends ResourceConfig {

    public TranslatorApplication() {
        register(TranslatorResource.class);
        register(BasicAuthFilter.class);
        register(CorsFilter.class);
        register(JacksonFeature.class);
    }
}
