package ma.darija.translator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.junit.jupiter.api.Test;

class ServiceTest {

    private static String basic(String u, String p) {
        return "Basic " + Base64.getEncoder().encodeToString((u + ":" + p).getBytes(StandardCharsets.UTF_8));
    }

    @Test
    void basicAuthAcceptsDefaultCredentialsOnly() {
        BasicAuthFilter f = new BasicAuthFilter();
        assertTrue(f.isAuthorized(basic("admin", "changeme")));
        assertFalse(f.isAuthorized(basic("admin", "wrong")));
        assertFalse(f.isAuthorized(basic("root", "changeme")));
        assertFalse(f.isAuthorized(null));
        assertFalse(f.isAuthorized("Bearer abc"));
        assertFalse(f.isAuthorized("Basic !!!notbase64"));
    }

    @Test
    void extractsTextFromChatCompletionResponse() throws Exception {
        String json = "{\"choices\":[{\"message\":{\"role\":\"assistant\",\"content\":\"<think>hmm</think>\\nالسلام عليكم\"}}]}";
        assertEquals("السلام عليكم", LlmClient.extractText(json));
    }

    @Test
    void promptMentionsScriptChoice() {
        assertTrue(LlmClient.systemPrompt("English", "latin").contains("Latin letters"));
        assertTrue(LlmClient.systemPrompt(null, null).contains("Arabic script"));
    }

    @Test
    void emptyTextIsRejected() {
        assertEquals(400, new TranslatorResource().doTranslate("  ", null, null).getStatus());
    }
}
