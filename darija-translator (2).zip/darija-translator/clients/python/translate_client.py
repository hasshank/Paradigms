#!/usr/bin/env python3
"""Python client for the Darija Translator REST service.

Usage:
    python translate_client.py "Hello, how are you?"
    python translate_client.py --script latin "Good morning"
    echo "Where is the train station?" | python translate_client.py
    python translate_client.py            # interactive mode (blank line to quit)

Environment: TRANSLATOR_URL, TRANSLATOR_USER, TRANSLATOR_PASSWORD
"""
import argparse
import os
import sys

import requests

URL = os.environ.get("TRANSLATOR_URL", "http://localhost:8080/api/translate")
USER = os.environ.get("TRANSLATOR_USER", "admin")
PASSWORD = os.environ.get("TRANSLATOR_PASSWORD", "changeme")


def translate(text: str, script: str = "arabic", source: str | None = None, url: str = URL) -> str:
    payload = {"text": text, "script": script}
    if source:
        payload["source"] = source
    resp = requests.post(url, json=payload, auth=(USER, PASSWORD), timeout=60)
    if resp.status_code == 401:
        raise SystemExit("Authentication failed: check TRANSLATOR_USER / TRANSLATOR_PASSWORD")
    if not resp.ok:
        try:
            msg = resp.json().get("error", resp.text)
        except ValueError:
            msg = resp.text
        raise SystemExit(f"Server error {resp.status_code}: {msg}")
    return resp.json()["translation"]


def main() -> None:
    parser = argparse.ArgumentParser(description="Translate text to Moroccan Darija")
    parser.add_argument("text", nargs="*", help="text to translate (default: stdin / interactive)")
    parser.add_argument("--script", choices=["arabic", "latin"], default="arabic")
    parser.add_argument("--source", help="source language hint, e.g. English")
    parser.add_argument("--url", default=URL)
    args = parser.parse_args()

    if args.text:
        print(translate(" ".join(args.text), args.script, args.source, args.url))
    elif not sys.stdin.isatty():
        print(translate(sys.stdin.read().strip(), args.script, args.source, args.url))
    else:
        print("Darija translator (blank line to quit)")
        while True:
            line = input("> ").strip()
            if not line:
                break
            print(translate(line, args.script, args.source, args.url))


if __name__ == "__main__":
    main()
