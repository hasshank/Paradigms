<?php
// Command-line variant: php cli.php "Hello, how are you?" [arabic|latin]
$url      = getenv('TRANSLATOR_URL') ?: 'http://localhost:8080/api/translate';
$user     = getenv('TRANSLATOR_USER') ?: 'admin';
$password = getenv('TRANSLATOR_PASSWORD') ?: 'changeme';

$text   = $argv[1] ?? null;
$script = $argv[2] ?? 'arabic';
if (!$text) {
    fwrite(STDERR, "Usage: php cli.php \"text\" [arabic|latin]\n");
    exit(1);
}

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERPWD        => "$user:$password",
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS     => json_encode(['text' => $text, 'script' => $script], JSON_UNESCAPED_UNICODE),
]);
$body = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

$data = json_decode((string) $body, true) ?? [];
if ($status !== 200) {
    fwrite(STDERR, "Error ($status): " . ($data['error'] ?? 'no response') . "\n");
    exit(1);
}
echo $data['translation'], "\n";
