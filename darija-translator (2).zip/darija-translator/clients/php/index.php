<?php
// PHP client for the Darija Translator REST service.
// Run:  php -S localhost:8000   (from this folder), then open http://localhost:8000
// Config via environment: TRANSLATOR_URL, TRANSLATOR_USER, TRANSLATOR_PASSWORD

$url      = getenv('TRANSLATOR_URL') ?: 'http://localhost:8080/api/translate';
$user     = getenv('TRANSLATOR_USER') ?: 'admin';
$password = getenv('TRANSLATOR_PASSWORD') ?: 'changeme';

function translate(string $url, string $user, string $password, string $text, string $script): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_HTTPAUTH       => CURLAUTH_BASIC,
        CURLOPT_USERPWD        => "$user:$password",
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json'],
        CURLOPT_POSTFIELDS     => json_encode(['text' => $text, 'script' => $script], JSON_UNESCAPED_UNICODE),
    ]);
    $body = curl_exec($ch);
    if ($body === false) {
        $err = curl_error($ch);
        curl_close($ch);
        return ['error' => "Cannot reach service: $err"];
    }
    $status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    $data = json_decode($body, true) ?? [];
    if ($status === 401) {
        return ['error' => 'Authentication failed'];
    }
    if ($status >= 400) {
        return ['error' => $data['error'] ?? "HTTP $status"];
    }
    return $data;
}

$text = '';
$script = 'arabic';
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $text   = trim($_POST['text'] ?? '');
    $script = ($_POST['script'] ?? 'arabic') === 'latin' ? 'latin' : 'arabic';
    if ($text !== '') {
        $result = translate($url, $user, $password, $text, $script);
    }
}
$h = fn(string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Darija Translator (PHP client)</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 640px; margin: 2rem auto; padding: 0 1rem; }
    textarea { width: 100%; padding: .6rem; font: inherit; }
    .result { margin-top: 1rem; padding: 1rem; border: 2px solid #006233; border-radius: 8px; font-size: 1.4rem; }
    .error { border-color: #c1272d; color: #c1272d; font-size: 1rem; }
    button { padding: .5rem 1rem; background: #c1272d; color: #fff; border: 0; border-radius: 6px; cursor: pointer; }
  </style>
</head>
<body>
  <h1>🇲🇦 Darija Translator</h1>
  <form method="post">
    <textarea name="text" rows="5" placeholder="Enter English, French… text"><?= $h($text) ?></textarea>
    <p>
      <select name="script">
        <option value="arabic" <?= $script === 'arabic' ? 'selected' : '' ?>>Arabic script</option>
        <option value="latin"  <?= $script === 'latin' ? 'selected' : '' ?>>Latin (Arabizi)</option>
      </select>
      <button type="submit">Translate</button>
    </p>
  </form>
  <?php if ($result !== null): ?>
    <?php if (isset($result['error'])): ?>
      <div class="result error"><?= $h($result['error']) ?></div>
    <?php else: ?>
      <div class="result" dir="auto"><?= $h($result['translation'] ?? '') ?></div>
    <?php endif; ?>
  <?php endif; ?>
</body>
</html>
