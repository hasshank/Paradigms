import React, { useState } from "react";
import {
  ActivityIndicator, SafeAreaView, ScrollView, StyleSheet, Switch,
  Text, TextInput, TouchableOpacity, View,
} from "react-native";
import { encode } from "base-64";
import * as Speech from "expo-speech";
import * as Clipboard from "expo-clipboard";

// Android emulator reaches the host machine at 10.0.2.2; on a real phone use your PC's LAN IP.
const DEFAULT_URL = "http://10.0.2.2:8080/api/translate";

// utf-8 safe Basic header
function basicAuth(user, pass) {
  const utf8 = unescape(encodeURIComponent(`${user}:${pass}`));
  return "Basic " + encode(utf8);
}

export default function App() {
  const [url, setUrl] = useState(DEFAULT_URL);
  const [user, setUser] = useState("admin");
  const [pass, setPass] = useState("changeme");
  const [text, setText] = useState("");
  const [latin, setLatin] = useState(false);
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  async function translate() {
    if (!text.trim()) return;
    setLoading(true); setError(""); setResult("");
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: basicAuth(user, pass) },
        body: JSON.stringify({ text, script: latin ? "latin" : "arabic" }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      setResult(data.translation);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  function readAloud() {
    if (!result) return;
    Speech.stop();
    // Moroccan Arabic voice when installed on the device, Arabic otherwise.
    Speech.speak(result, { language: "ar-MA" });
  }

  return (
    <SafeAreaView style={s.container}>
      <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">
        <Text style={s.title}>🇲🇦 Darija Translator</Text>

        <TextInput
          style={s.input} multiline value={text} onChangeText={setText}
          placeholder="Type text in English, French…" placeholderTextColor="#888"
        />
        <View style={s.row}>
          <Text>Latin (Arabizi)</Text>
          <Switch value={latin} onValueChange={setLatin} />
        </View>

        <TouchableOpacity style={s.primary} onPress={translate} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.primaryText}>Translate</Text>}
        </TouchableOpacity>

        {!!error && <Text style={s.error}>{error}</Text>}
        {!!result && (
          <View style={s.result}>
            <Text style={s.resultText}>{result}</Text>
            <View style={s.row}>
              <TouchableOpacity style={s.secondary} onPress={readAloud}><Text>🔊 Read aloud</Text></TouchableOpacity>
              <TouchableOpacity style={s.secondary} onPress={() => Speech.stop()}><Text>⏹</Text></TouchableOpacity>
              <TouchableOpacity style={s.secondary} onPress={() => Clipboard.setStringAsync(result)}><Text>Copy</Text></TouchableOpacity>
            </View>
          </View>
        )}

        <TouchableOpacity onPress={() => setShowSettings(!showSettings)}>
          <Text style={s.link}>{showSettings ? "Hide" : "Show"} server settings</Text>
        </TouchableOpacity>
        {showSettings && (
          <View>
            <TextInput style={s.input} value={url} onChangeText={setUrl} autoCapitalize="none" placeholder="Service URL" />
            <TextInput style={s.input} value={user} onChangeText={setUser} autoCapitalize="none" placeholder="Username" />
            <TextInput style={s.input} value={pass} onChangeText={setPass} secureTextEntry placeholder="Password" />
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  scroll: { padding: 16, gap: 12 },
  title: { fontSize: 22, fontWeight: "700", marginTop: 24 },
  input: { borderWidth: 1, borderColor: "#bbb", borderRadius: 8, padding: 10, minHeight: 44, fontSize: 16 },
  row: { flexDirection: "row", gap: 8, alignItems: "center", justifyContent: "space-between", marginTop: 8 },
  primary: { backgroundColor: "#c1272d", padding: 14, borderRadius: 8, alignItems: "center" },
  primaryText: { color: "#fff", fontWeight: "600", fontSize: 16 },
  secondary: { borderWidth: 1, borderColor: "#bbb", borderRadius: 8, paddingVertical: 8, paddingHorizontal: 12 },
  result: { borderWidth: 2, borderColor: "#006233", borderRadius: 8, padding: 12 },
  resultText: { fontSize: 22, writingDirection: "rtl" },
  error: { color: "#c1272d" },
  link: { color: "#006233", marginTop: 8 },
});
