# Darija Translator — LLM-powered RESTful Web Service

Translate text from any language (English, French, …) into **Moroccan Arabic (Darija)** using a **Qwen** LLM (Ollama or Alibaba DashScope), exposed as a Jakarta REST endpoint and consumed by a Chrome extension, PHP, Python and React Native clients.

```
darija-translator/
├── colab/             Google Colab notebook: Ollama + Qwen + server + public tunnel
├── server/            Maven project: Jakarta REST (Jersey) + embedded Grizzly + Qwen client
├── chrome-extension/  Manifest V3 extension using chrome.sidePanel
├── clients/
│   ├── python/        CLI client (requests)
│   ├── php/           Web page + CLI client (cURL)
│   └── react-native/  Expo mobile app
└── docs/              PlantUML: class, sequence, use-case, deployment diagrams
```

## 0. Run everything on Google Colab (easiest)

1. Zip this folder as `darija-translator.zip` (or use the one provided).
2. Open `colab/darija_translator_colab.ipynb` in Colab (File ▸ Upload notebook), choose **Runtime ▸ Change runtime type ▸ T4 GPU**.
3. Run the cells in order. They install JDK 17, Maven and Ollama, pull `qwen2.5:7b-instruct`, build and start the REST service, and print a public `https://….trycloudflare.com/api/translate` URL.
4. Paste that URL, the username and the password into the Chrome extension's *Server settings* (or the `TRANSLATOR_*` variables of the other clients).

The tunnel URL changes each run, and the service stops when the Colab runtime stops. Use a strong `AUTH_PASSWORD` because the URL is public.

## 1. Server (local machine)

Requirements: JDK 17+, Maven 3.9+, and a Qwen model behind an OpenAI-compatible API. The simplest is [Ollama](https://ollama.com): `ollama pull qwen2.5:7b-instruct`.

```bash
cd server
export LLM_BASE_URL=http://localhost:11434/v1   # default (Ollama)
export LLM_MODEL=qwen2.5:7b-instruct            # default
export AUTH_USER=admin            # optional, default admin
export AUTH_PASSWORD=changeme     # optional, default changeme
mvn package
java -jar target/translator-service-1.0.0.jar
```

On Windows PowerShell use `$env:LLM_MODEL="qwen2.5:7b-instruct"`.

Hosted Qwen instead of Ollama (Alibaba Cloud DashScope):
```bash
export LLM_BASE_URL=https://dashscope-intl.aliyuncs.com/compatible-mode/v1
export LLM_MODEL=qwen-plus
export LLM_API_KEY=sk-...
```

### Endpoint

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/translate` | Basic | Body `{"text": "...", "source": "English" (optional), "script": "arabic" \| "latin"}` |
| GET | `/api/translate?text=...&script=...` | Basic | Same, via query string |
| GET | `/api/translate/health` | none | Liveness probe |

```bash
curl -u admin:changeme -X POST http://localhost:8080/api/translate \
  -H "Content-Type: application/json" \
  -d '{"text":"Hello, how are you?"}'
# {"original":"Hello, how are you?","translation":"السلام، لاباس عليك؟","model":"qwen2.5:7b-instruct"}
```

Errors are JSON: `{"error": "..."}` with 400 (bad input), 401 (auth), 502 (LLM unreachable or failed).

### Design notes

- `TranslatorResource.translate()` is the business method; it delegates to `LlmClient`, which calls the OpenAI-compatible `/chat/completions` API with a system prompt (including short examples) that forces natural Darija (Arabic script or Arabizi) and bare output. Any `<think>` block emitted by reasoning models is stripped.
- **Security**: `BasicAuthFilter` is a `ContainerRequestFilter` implementing HTTP Basic authentication with constant-time comparison. The brief allows basic authentication; a full Jakarta Authentication (JASPIC) `ServerAuthModule` would be needed only in a Jakarta EE application server. Basic credentials are only Base64-encoded, so put the service behind HTTPS outside localhost.
- **Embedded container**: Grizzly is started from `Main`, so no application server is required.
- Switching model or provider is configuration only (`LLM_BASE_URL`, `LLM_MODEL`, `LLM_API_KEY`). Larger Qwen models give better Darija; 7B is acceptable, 1.5B is weak.

## 2. Chrome extension

1. Open `chrome://extensions`, enable **Developer mode**, click **Load unpacked**, select `chrome-extension/`.
2. Select text on any page → right-click → **Translate to Darija**. The side panel opens, the selected text is pasted automatically and translated. `Alt+D` does the same from the keyboard.
3. In the panel: **Read aloud** (speech synthesis, prefers `ar-MA`), **🎤** dictation, **🎙️ Voice → Voice** (speak → translate → read aloud), Arabic/Latin output toggle, and **Server settings** (URL, username, password, dictation language).

Notes: Chrome 116+ is required. Dictation needs microphone permission and Chrome's speech service; if blocked, allow the microphone for the extension in Chrome site settings. Voice availability for `ar-MA` depends on the OS; Chrome falls back to any Arabic voice. `*.trycloudflare.com` (Colab tunnel) and localhost are pre-approved; for any other server add its origin to `host_permissions` in `manifest.json`.

## 3. Clients

**Python**
```bash
cd clients/python && pip install -r requirements.txt
python translate_client.py "Good morning" --script latin
```

**PHP** (needs the cURL extension)
```bash
cd clients/php
php -S localhost:8000          # open http://localhost:8000
php cli.php "Where is the station?"
```

**React Native (Expo)**
```bash
cd clients/react-native
npm install
npx expo start
```
The default URL `http://10.0.2.2:8080/api/translate` works from the Android emulator. On a physical phone, open *Server settings* in the app and use your computer's LAN IP. The app includes read-aloud via `expo-speech` and a copy button.

All clients read `TRANSLATOR_URL`, `TRANSLATOR_USER`, `TRANSLATOR_PASSWORD` where applicable (Python, PHP).

## 4. UML

PlantUML sources are in `docs/` (`class-diagram.puml`, `sequence-diagram.puml`, `usecase-diagram.puml`, `deployment-diagram.puml`). Render them with the VS Code PlantUML extension or <https://www.plantuml.com/plantuml>, or `java -jar plantuml.jar docs/*.puml`.

## 5. Still to do on your side

- Run the Colab notebook (or `mvn package`) once: the code was written without access to Maven Central or a Qwen model, so it has not been compiled or run end-to-end.
- Record the 5-minute demo video, push to GitHub with commits and this README, and optionally publish a blog post.
